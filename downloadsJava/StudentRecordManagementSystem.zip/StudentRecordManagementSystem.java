import java.util.*;

public class StudentRecordManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int studentCount;
            while (true) {
            try {
                System.out.print("How many students? ");
                studentCount = scanner.nextInt();
                scanner.nextLine();

                if (studentCount > 0) {
                    break;
                } else {
                    System.out.println("Number of students must be greater than 0.");
                }

            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a whole number.");
                scanner.nextLine(); // Clear invalid input
            }
        }

        int[] studentIDs = new int[studentCount];
        String[] studentNames= new String[studentCount];
        String[] courses = new String[studentCount];
        int[] studentGrades = new int[studentCount];
        boolean hasData = false;

        while (true){
            System.out.println("\n");
            System.out.println("-".repeat(50));
            System.out.println("----- STUDENT RECORD MANAGEMENT SYSTEM -----");
            System.out.println("-".repeat(50));
            System.out.println("\n1 - Add Student/s");
            System.out.println("2 - Display Students");
            System.out.println("3 - Linear Search by ID");
            System.out.println("4 - Binary Search by ID");
            System.out.println("5 - Search by Name");
            System.out.println("6 - Display Statistics");
            System.out.println("7 - Prefix Sum of Grades");
            System.out.println("8 - Frequency Counter (Grades)");
            System.out.println("9 - Duplicate Student IDs");
            System.out.println("10 - Reverse Student Names (Recursion)");
            System.out.println("0 - Exit");

            try {
                System.out.print("\nEnter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine();
                if (!hasData && choice != 1 && choice != 0) {
                    System.out.println("Please add students first.");
                    continue;
                }

                switch (choice) {
                    case 0 -> {
                        exit(5);
                        scanner.close();
                        return;
                    }
                    case 1 -> {
                        addStudent(studentIDs, studentNames, courses, studentGrades, scanner);
                        hasData = true;
                    }

                    case 2 -> displayStudents(studentIDs, studentNames, courses, studentGrades);
                    case 3 -> linearID(studentIDs, studentNames, courses, studentGrades, scanner);
                    case 4 -> binaryID(studentIDs, studentNames, courses, studentGrades, scanner);
                    case 5 -> nameSearch(studentIDs, studentNames, courses, studentGrades, scanner);
                    case 6 -> displayStatistics(studentIDs, studentNames, courses, studentGrades);
                    case 7 -> prefixSum(studentIDs, studentNames, courses, studentGrades, scanner);
                    case 8 -> frequencyCounter(studentIDs, studentNames, courses, studentGrades, scanner);
                    case 9 -> duplicateFinder(studentIDs, studentNames, courses, studentGrades);
                    case 10 -> reverseName(studentIDs, studentNames, courses, studentGrades, scanner);

                    default -> System.out.println("Invalid input. Please enter a number between 0 - 10");

                }

            }
            catch (InputMismatchException e) {
                System.out.println("Invalid. Please enter a whole number.");
                scanner.nextLine();
            }
        }
    }   

    // Exit
    public static void exit(int n){
        if (n == 0){
            System.out.println("\n");
            System.out.println("-".repeat(50));
            System.out.println("----- THANK YOU FOR USING OUR PROGRAM -----");
            System.out.println("-".repeat(50));
            return;
        }

        System.out.println("Exiting in " + n + "...");
        exit(n -1);
    }

    // Add Student
    public static void addStudent(int[] studentIDs, String[] studentNames, String[] courses, int[] studentGrades, Scanner scanner){
        int id;
        String name;
        String course;
        int grade;

        
        for (int i = 0; i< studentIDs.length; i++){
            // ID
            while(true){
                try {
                    System.out.print("\nEnter Student ID: ");
                    id = scanner.nextInt();
                    scanner.nextLine();

                    if (id >= 1000 && id <= 1999){
                        studentIDs[i] = id;
                        break;
                    }
                    System.out.println("\n----- Please enter a number between 1000 to 1999 -----");
                
                } catch (InputMismatchException e) {
                    System.out.println("\n----- Invalid. Please enter a whole number -----");
                    scanner.nextLine();
                }
            }

            // Name and Course
            while(true){
                System.out.print("Enter Student Name: ");
                    name = scanner.nextLine();

                    System.out.print("Enter Student Course: ");
                    course= scanner.nextLine();

                    if (name.trim().isEmpty()|| course.trim().isEmpty()) {
                        System.out.println("----- Try again. Name or Course must not be empty -----");
                    } else {
                        studentNames[i] = name;
                        courses[i] = course;
                        break;
                    }
            }

            // Grade
            while(true){
                try {
                    System.out.print("Enter Student Grade: ");
                    grade = scanner.nextInt();
                    scanner.nextLine();

                    if (grade >= 0 && grade <= 100){
                        studentGrades[i] = grade;
                        break;
                    }
                        System.out.println("\n----- Please enter a number between 0 to 100 -----");
                } catch (InputMismatchException e) {
                    System.out.println("\n----- Invalid. Please enter a whole number -----");
                    scanner.nextLine();
                }
            }
        }
    }

    // Display Students
    public static void displayStudents(int[] studentIDs, String[] studentNames, String[] courses, int[] studentGrades){
        System.out.println("\n");
        System.out.println("-".repeat(50));
        System.out.println("---------------- STUDENTS RECORD ----------------");
        System.out.println("-".repeat(50));

        System.out.printf("%-6s %-20s %-15s %-6s%n" , "ID", "Name", "Course", "Grade");
        for (int i = 0; i < studentIDs.length; i++){
            System.out.printf("%-6d %-20s %-15s %-6d%n", studentIDs[i], studentNames[i], courses[i], studentGrades[i]);
            System.out.println("-".repeat(40));
        }
    }


    // Linear Search through Student ID
    public static void linearID(int[] studentIDs, String[] studentNames, String[] courses, int[] studentGrades, Scanner scanner){
        int comparison = 0;
        boolean hasFound = false;
        int searchID;

            // ID
            while(true){
                try {
                    System.out.print("\nEnter Student ID: ");
                    searchID = scanner.nextInt();
                    scanner.nextLine();

                    if (searchID >= 1000 && searchID <= 1999){
                        break;
                    }
                    else{
                        System.out.println("\n----- Please enter a number between 1000 to 1999 -----");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("\n----- Invalid. Please enter a whole number -----");
                    scanner.nextLine();
                }
            }

            System.out.println("-".repeat(60));
            System.out.printf("| %-6s | %-20s | %-14s | %-5s |%n",
                    "ID", "Name", "Course", "Grade");
            System.out.println("-".repeat(60));
            for (int i = 0; i <studentIDs.length; i++){
                comparison ++;
                if (studentIDs[i] == searchID){
                    System.out.printf("| %-6d | %-20s | %-14s | %-5d |%n",
                    studentIDs[i],
                    studentNames[i],
                    courses[i],
                    studentGrades[i]);
                    System.out.println("Index: " + i);

                    hasFound = true;
                    break;
                }
            }
            if (!hasFound){
                System.out.println("\nStudent not found.");
            }
            
            System.out.println("Comparisons: " + comparison);
            System.out.println("Time Complexity: O(n)");
            System.out.println("-".repeat(60));
    }

    // Swap Student for Binary ID
    public static void swap(int[] studentIDs, String[] studentNames, String[] courses, int[] studentGrades, int first, int second){
        int tempID = studentIDs[first];
        studentIDs[first] = studentIDs[second];
        studentIDs[second] = tempID;

        String tempName = studentNames[first];
        studentNames[first] = studentNames[second];
        studentNames[second] = tempName;

        String tempCourse = courses[first];
        courses[first] = courses[second];
        courses[second] = tempCourse;

        int tempGrade = studentGrades[first];
        studentGrades[first] = studentGrades[second];
        studentGrades[second] = tempGrade;
    }

    // Bubble Sort
    public static void sort(int[] studentIDs, String[] studentNames, String[] courses, int[] studentGrades){
        for(int i = 0; i < studentIDs.length - 1; i++){
            for (int j = 0; j < studentIDs.length - i - 1;j++){
                if (studentIDs[j] > studentIDs[j+1]){
                    swap(studentIDs, studentNames, courses, studentGrades, j, j+1);
                }
            }
        }
    }

    // Binary Search through Student ID
    public static void binaryID(int[] studentIDs, String[] studentNames, String[] courses, int[] studentGrades, Scanner scanner){
        int[] tempIDs = studentIDs.clone();
        String[] tempNames = studentNames.clone();
        String[] tempCourses = courses.clone();
        int[] tempGrades = studentGrades.clone();

        sort(tempIDs, tempNames, tempCourses, tempGrades);

        boolean hasFound = false;
        int comparison = 0;
        int searchID;

        int low = 0;
        int high = tempIDs.length - 1;

        while (true){
            try {
                System.out.print("Enter Student ID: ");
                searchID = scanner.nextInt();
                scanner.nextLine();

                if (searchID >= 1000 && searchID <= 1999){
                    break;
                }

                System.out.println("Please enter a number between 1000 - 1999.");

            } catch (InputMismatchException e){
                System.out.println("Invalid. Please enter a whole number.");
                scanner.nextLine();
            }
        }

        System.out.println("-".repeat(60));
            System.out.printf("| %-6s | %-20s | %-14s | %-5s |%n",
                    "ID", "Name", "Course", "Grade");
            System.out.println("-".repeat(60));
        while (low <= high){
            int mid = (low + high) / 2;
            comparison++;
            
            if (tempIDs[mid] == searchID){
                System.out.printf("| %-6d | %-20s | %-14s | %-5d |%n",
                    tempIDs[mid],
                    tempNames[mid],
                    tempCourses[mid],
                    tempGrades[mid]);
                    System.out.println("Index: " + mid);

                    hasFound = true;
                
        break;}
            else if (searchID > tempIDs[mid]){
                low = mid + 1;
            }
            else{
                high = mid -1;
            }
        }
        if (!hasFound){
                System.out.println("\nStudent not found.");
            }
            
            System.out.println("Comparisons: " + comparison);
            System.out.println("Time Complexity: O(log n)");
            System.out.println("-".repeat(60));
    }

    // Name Search
    public static void nameSearch(int[] studentIDs, String[] studentNames, String[] courses, int[] studentGrades, Scanner scanner){
        String searchName;
        boolean hasFound = false;
        
        while(true){
            System.out.print("Enter Student Name: ");
                searchName = scanner.nextLine();

                if (searchName.trim().isEmpty()) {
                    System.out.println("----- Try again. Name or Course must not be empty -----");
                } else {
                    break;
                }
            }
            
        while(true){
            for(int i = 0; i < studentNames.length; i++){
                if (studentNames[i].equalsIgnoreCase(searchName)){
                    System.out.println("----- STUDENT FOUND -----");
                    System.out.printf("| %-6d | %-20s | %-14s | %-5d |%n",
                    studentIDs[i],
                    studentNames[i],
                    courses[i],
                    studentGrades[i]);
                    System.out.println("Index: " + i);

                    hasFound = true;
                }   
            }
            break;  
        }

        if (!hasFound){
            System.out.println("\nStudent not found.");
        }
    }

    // Display Statistics
    public static void displayStatistics(int[] studentIDs, String[] studentNames,
                                     String[] courses, int[] studentGrades) {

    int highestIndex = 0;
    int lowestIndex = 0;
    double total = 0;

    for (int i = 0; i < studentGrades.length; i++) {

        if (studentGrades[i] > studentGrades[highestIndex]) {
            highestIndex = i;
        }

        if (studentGrades[i] < studentGrades[lowestIndex]) {
            lowestIndex = i;
        }

        total += studentGrades[i];
    }

    double average = total / studentGrades.length;

    System.out.println("\n" + "-".repeat(50));
    System.out.println("---------- STUDENT STATISTICS ----------");
    System.out.println("-".repeat(50));

    System.out.println("\nHighest Grade");
    System.out.println("ID     : " + studentIDs[highestIndex]);
    System.out.println("Name   : " + studentNames[highestIndex]);
    System.out.println("Course : " + courses[highestIndex]);
    System.out.println("Grade  : " + studentGrades[highestIndex]);

    System.out.println("\nLowest Grade");
    System.out.println("ID     : " + studentIDs[lowestIndex]);
    System.out.println("Name   : " + studentNames[lowestIndex]);
    System.out.println("Course : " + courses[lowestIndex]);
    System.out.println("Grade  : " + studentGrades[lowestIndex]);

    System.out.printf("%nClass Average: %.2f%n", average);
}

    // Prefix Sum
    public static void prefixSum(int[] studentIDs, String[] studentNames, String[] courses, int[] studentGrades, Scanner scanner){
        int[] prefix =  new int[studentGrades.length];
        prefix[0] = studentGrades[0];

        for (int i =1;i <studentGrades.length;i++){
            prefix[i] = prefix[i-1] + studentGrades[i];
        }
        try{
            System.out.print("Starting Index: ");
            int left = scanner.nextInt();

            System.out.print("Ending Index: ");
            int right = scanner.nextInt();
            scanner.nextLine();

            if (left < 0 || right >= studentGrades.length || left > right){
                System.out.println("Invalid indexes. Try again.");
                return;
            }

            int sum;

            if(left == 0){
                sum = prefix[right];
            }
            else{
                sum = prefix[right] - prefix[left-1];
            }

            System.out.println("Sum of index "+ left + " to " + right + " = " + sum);}
        catch(InputMismatchException e){
            System.out.println("Invalid. Please try again.");
        }
    }

    // Frequency Counter
    public static void frequencyCounter(int[] studentIDs, String[] studentNames, String[] courses, int[] studentGrades, Scanner scanner){
        int count = 0;
        int searchGrade;

        while(true){
                try {
                    System.out.print("Enter Student Grade: ");
                    searchGrade = scanner.nextInt();
                    scanner.nextLine();

                    if (searchGrade >= 0 && searchGrade <= 100){
                        break;
                    }
                        System.out.println("\n----- Please enter a number between 0 to 100 -----");
                } catch (InputMismatchException e) {
                    System.out.println("\n----- Invalid. Please enter a whole number -----");
                    scanner.nextLine();
                }
            }

        for (int num : studentGrades){
            if (num == searchGrade){
                count++;
            }
        }

        System.out.println("Frequency Count for grade of "  + searchGrade + " is " + count + ".");   

    }

    // Duplicate Finder
    public static void duplicateFinder(int[] studentIDs, String[] studentNames, String[] courses, int[] studentGrades){
         boolean duplicateFound = false;

        for (int i = 0; i < studentIDs.length -1; i++) {
            for (int j = i +1; j<studentIDs.length; j ++){
                if (studentIDs[i] == studentIDs[j]){
                    System.out.println("----- Duplicate Found -----");
                    System.out.println("Value " + studentIDs[i] );
                    System.out.println("Indexes: " + i + " and " + j);
                    duplicateFound = true;
                }
            }
        }

        if (!duplicateFound){
            System.out.println("No duplicates found.");
        }
    }

    // Name Reverser
        public static void reverseName(int[] studentIDs, String[] studentNames,
            String[] courses, int[] studentGrades, Scanner scanner) {

        System.out.print("Enter Student ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < studentIDs.length; i++) {

            if (studentIDs[i] == id) {

                System.out.println("Original Name: " + studentNames[i]);
                System.out.println("Reversed Name: " + reverse(studentNames[i]));
                return;
            }
        }

        System.out.println("Student not found.");
    }
    public static String reverse(String word) {

        if (word.isEmpty()) {
            return "";
        }

        return reverse(word.substring(1)) + word.charAt(0);
    }
}