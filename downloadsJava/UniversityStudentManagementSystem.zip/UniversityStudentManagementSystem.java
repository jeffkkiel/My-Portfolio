import java.util.*;

class Action {
    String type;
    Object data;

    Action(String type, Object data) {
        this.type = type;
        this.data = data;
    }
}

class Student {
    int studentID;
    String name;
    String course;
    double gpa;

    Student(int studentID, String name, String course, double gpa) {
        this.studentID = studentID;
        this.name = name;
        this.course = course;
        this.gpa = gpa;
    }

    // Display Student Information
    void display() {
        System.out.println("Student ID : " + studentID);
        System.out.println("Name       : " + name);
        System.out.println("Course     : " + course);
        System.out.printf("GPA        : %.2f%n", gpa);
    }
}

class UniversityManager {

    private Scanner scanner;

    // Java Collections Framework
    private ArrayList<Student> students;
    private LinkedList<String> announcements;
    private Stack<Action> recentActions;
    private Queue<Student> enrollmentQueue;
    private PriorityQueue<Student> honorStudents;
    private Deque<String> emergencyMessages;

    // Constructor
    public UniversityManager(Scanner scanner) {

        this.scanner = scanner;

        students = new ArrayList<>();
        announcements = new LinkedList<>();
        recentActions = new Stack<>();
        enrollmentQueue = new LinkedList<>();

        // Highest GPA has the highest priority
        honorStudents = new PriorityQueue<>(
                (a, b) -> Double.compare(b.gpa, a.gpa)
        );

        emergencyMessages = new ArrayDeque<>();
    }

    // Check if at least one student exists
    public boolean hasStudents() {
        return !students.isEmpty();
    }

    // ==========================================
    // INPUT STUDENT
    // ==========================================
    public Student inputStudent() {

        int studentID;
        String name;
        String course;
        double gpa;

        System.out.println();
        System.out.println("=".repeat(50));
        System.out.println("       ENTER STUDENT INFORMATION");
        System.out.println("=".repeat(50));

        // ---------------- Student ID ----------------
        while (true) {
            try {
                System.out.print("Student ID (1000-1999): ");
                studentID = scanner.nextInt();
                scanner.nextLine();

                if (studentID < 1000 || studentID > 1999) {
                    System.out.println("Invalid ID. Must be between 1000 and 1999.");
                    continue;
                }

                // Prevent duplicate Student IDs
                boolean duplicate = false;

                for (Student student : students) {
                    if (student.studentID == studentID) {
                        duplicate = true;
                        break;
                    }
                }

                if (duplicate) {
                    System.out.println("Student ID already exists.");
                    continue;
                }

                break;

            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a whole number.");
                scanner.nextLine();
            }
        }

        // ---------------- Name & Course ----------------
        while (true) {

            System.out.print("Student Name : ");
            name = scanner.nextLine();

            System.out.print("Course       : ");
            course = scanner.nextLine();

            if (name.trim().isEmpty() || course.trim().isEmpty()) {
                System.out.println("Name or Course cannot be empty.");
                continue;
            }

            break;
        }

        // ---------------- GPA ----------------
        while (true) {

            try {

                System.out.print("GPA (0.00 - 4.00): ");
                gpa = scanner.nextDouble();
                scanner.nextLine();

                if (gpa < 0 || gpa > 4.00) {
                    System.out.println("GPA must be between 0.00 and 4.00.");
                    continue;
                }

                break;

            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid decimal number.");
                scanner.nextLine();
            }
        }

        return new Student(studentID, name, course, gpa);
    }

// ==========================================
// CASE 1 - ADD STUDENT
// ==========================================
public void addStudent() {

    Student student = inputStudent();

    students.add(student);
    recentActions.push(new Action("Student", student));

    System.out.println("\n" + "=".repeat(50));
    System.out.println("Student added successfully!");
    System.out.println("Student ID : " + student.studentID);
    System.out.println("Name       : " + student.name);
    System.out.println("=".repeat(50));
}


// ==========================================
// CASE 2 - DISPLAY STUDENTS
// ==========================================
public void displayStudents() {

    if (students.isEmpty()) {
        System.out.println("\nNo students found.");
        return;
    }

    System.out.println("\n" + "=".repeat(55));
    System.out.println("             UNIVERSITY STUDENT LIST");
    System.out.println("=".repeat(55));

    for (int i = 0; i < students.size(); i++) {

        System.out.println("\nStudent #" + (i + 1));
        System.out.println("-".repeat(40));

        students.get(i).display();
    }

    System.out.println("=".repeat(55));
}


// ==========================================
// CASE 3 - ADD ANNOUNCEMENTS
// ==========================================
public void addAnnouncement() {

    int count;

    while (true) {

        try {

            System.out.print("How many announcements do you want to add? ");
            count = scanner.nextInt();
            scanner.nextLine();

            if (count > 0)
                break;

            System.out.println("Number of announcements must be greater than 0.");

        } catch (InputMismatchException e) {

            System.out.println("Invalid input. Please enter a whole number.");
            scanner.nextLine();
        }
    }

    for (int i = 1; i <= count; i++) {

        String announcement;

        while (true) {

            System.out.print("Announcement #" + i + " : ");
            announcement = scanner.nextLine();

            if (!announcement.trim().isEmpty())
                break;

            System.out.println("Announcement cannot be empty.");
        }

        announcements.add(announcement);
        recentActions.push(new Action("Announcement", announcement));
    }

    System.out.println("\nAnnouncements added successfully.");
}


// ==========================================
// CASE 4 - DISPLAY ANNOUNCEMENTS
// ==========================================
public void displayAnnouncements() {

    if (announcements.isEmpty()) {

        System.out.println("\nNo announcements found.");
        return;
    }

    System.out.println("\n" + "=".repeat(55));
    System.out.println("          UNIVERSITY ANNOUNCEMENTS");
    System.out.println("=".repeat(55));

    for (int i = 0; i < announcements.size(); i++) {

        System.out.println((i + 1) + ". " + announcements.get(i));
    }

    System.out.println("=".repeat(55));
}

 // ==========================================
// CASE 5 - UNDO LAST ACTION
// ==========================================
public void undoAction() {

    if (recentActions.isEmpty()) {
        System.out.println("\nNo actions to undo.");
        return;
    }

    Action last = recentActions.pop();

    switch (last.type) {

        case "Student" -> {
            Student student = (Student) last.data;
            students.remove(student);
            System.out.println("Last added student removed.");
        }

        case "Announcement" -> {
            String announcement = (String) last.data;
            announcements.removeLastOccurrence(announcement);
            System.out.println("Last announcement removed.");
        }

        case "Emergency" -> {
            String message = (String) last.data;
            emergencyMessages.removeLastOccurrence(message);
            System.out.println("Last emergency message removed.");
        }

        case "Enroll" -> {
            Student student = (Student) last.data;
            enrollmentQueue.remove(student);
            System.out.println("Last enrollee removed from the queue.");
        }

        case "Honors" -> {
            Student student = (Student) last.data;
            honorStudents.remove(student);
            System.out.println("Honor student removed.");
        }

        default -> System.out.println("Unknown action.");
    }
}


// ==========================================
// CASE 6 - ENROLL STUDENT (QUEUE)
// ==========================================
public void enqueueStudent() {

    if (students.isEmpty()) {
        System.out.println("No students available.");
        return;
    }

    System.out.println("\n===== STUDENT LIST =====");

    for (int i = 0; i < students.size(); i++) {
        System.out.println("Student # " + (i + 1));
        students.get(i).display();
        System.out.println("-".repeat(40));
    }

    int studentNumber;

    while (true) {

        try {

            System.out.print("Choose Student Number to Enroll: ");
            studentNumber = scanner.nextInt();
            scanner.nextLine();

            if (studentNumber >= 1 && studentNumber <= students.size())
                break;

            System.out.println("Invalid student number.");

        }

        catch (InputMismatchException e) {
            System.out.println("Invalid input.");
            scanner.nextLine();
        }
    }

    Student selectedStudent = students.get(studentNumber - 1);

    if (enrollmentQueue.contains(selectedStudent)) {
        System.out.println("Student is already in the enrollment queue.");
        return;
    }

    enrollmentQueue.offer(selectedStudent);

    recentActions.push(new Action("Enroll", selectedStudent));

    System.out.println(selectedStudent.name + " has been added to the enrollment queue.");
}

// ==========================================
// CASE 7 - SERVE NEXT STUDENT
// ==========================================
public void serveNextStudent() {

    if (enrollmentQueue.isEmpty()) {
        System.out.println("Enrollment queue is empty.");
        return;
    }

    Student served = enrollmentQueue.poll();

    System.out.println("\n===== NOW SERVING =====");
    served.display();
}

// ==========================================
// CASE 8 - DISPLAY ENROLLMENT QUEUE
// ==========================================
public void displayEnrollmentQueue() {

    if (enrollmentQueue.isEmpty()) {
        System.out.println("Enrollment queue is empty.");
        return;
    }

    System.out.println("\n========== ENROLLMENT QUEUE ==========");

    int number = 1;

    for (Student student : enrollmentQueue) {

        if (number == 1)
            System.out.println("FRONT");

        System.out.println("\nStudent #" + number++);
        student.display();
    }

    System.out.println("\nREAR");
}

 // ==========================================
// CASE 9 - ADD HONOR STUDENT
// ==========================================
public void addHonorStudent() {

    if (students.isEmpty()) {
        System.out.println("No students available.");
        return;
    }

    System.out.println("\n===== STUDENT LIST =====");

    for (int i = 0; i < students.size(); i++) {
        System.out.println("Student # " + (i + 1));
        students.get(i).display();
        System.out.println("-".repeat(40));
    }

    int studentNumber;

    while (true) {

        try {

            System.out.print("Choose Student Number: ");
            studentNumber = scanner.nextInt();
            scanner.nextLine();

            if (studentNumber >= 1 && studentNumber <= students.size())
                break;

            System.out.println("Invalid student number.");

        } catch (InputMismatchException e) {
            System.out.println("Invalid input.");
            scanner.nextLine();
        }
    }

    Student selectedStudent = students.get(studentNumber - 1);

    if (honorStudents.contains(selectedStudent)) {
        System.out.println("Student is already an Honor Student.");
        return;
    }

    honorStudents.offer(selectedStudent);

    recentActions.push(new Action("Honors", selectedStudent));

    System.out.println(selectedStudent.name + " added to Honor Students.");
}


// ==========================================
// CASE 10 - DISPLAY HONOR STUDENTS
// ==========================================
public void displayHonorStudents() {

    if (honorStudents.isEmpty()) {
        System.out.println("No honor students.");
        return;
    }

    PriorityQueue<Student> temp = new PriorityQueue<>(honorStudents);

    int rank = 1;

    System.out.println("\n===== HONOR STUDENTS =====");

    while (!temp.isEmpty()) {

        Student student = temp.poll();

        System.out.println("Rank #" + rank++);
        student.display();
        System.out.println("-".repeat(40));
    }
}


// ==========================================
// CASE 11 - ADD EMERGENCY MESSAGE
// ==========================================
public void manageEmergencyMessages() {

    String emergencyMessage;

    while (true) {

        System.out.print("Enter Emergency Message: ");
        emergencyMessage = scanner.nextLine();

        if (!emergencyMessage.trim().isEmpty())
            break;

        System.out.println("Emergency Message cannot be empty.");
    }

    emergencyMessages.addLast(emergencyMessage);

    recentActions.push(new Action("Emergency", emergencyMessage));

    System.out.println("\nEmergency message added successfully.");
}


// ==========================================
// CASE 112- DISPLAY EMERGENCY MESSAGES
// ==========================================
public void displayEmergencyMessages() {

    if (emergencyMessages.isEmpty()) {
        System.out.println("No emergency messages found.");
        return;
    }

    System.out.println("\n" + "=".repeat(55));
    System.out.println("           EMERGENCY MESSAGES");
    System.out.println("=".repeat(55));

    int number = 1;

    for (String message : emergencyMessages) {
        System.out.println(number++ + ". " + message);
    }

    System.out.println("=".repeat(55));
}

// ==========================================
// CASE 13 - DISPLAY STATISTICS
// ==========================================
public void displayStatistics() {

    System.out.println("\n========== SYSTEM STATISTICS ==========");

    System.out.println("Students           : " + students.size());

    System.out.println("Announcements      : " + announcements.size());

    System.out.println("Enrollment Queue   : " + enrollmentQueue.size());

    System.out.println("Honor Students     : " + honorStudents.size());

    System.out.println("Emergency Messages : " + emergencyMessages.size());

    System.out.println("Undo History       : " + recentActions.size());
}}



public class UniversityStudentManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UniversityManager manager = new UniversityManager(scanner);

        while (true) {
            System.out.println("\n" + "=".repeat(60));
            System.out.println("         UNIVERSITY MANAGEMENT SYSTEM");
            System.out.println("=".repeat(60));

            System.out.println("\n[1] Add Student");
            System.out.println("[2] View Students");
            System.out.println("[3] Add Announcements");
            System.out.println("[4] View Announcements");
            System.out.println("[5] Undo Last Action");
            System.out.println("[6] Enroll Student");
            System.out.println("[7] Serve Next Student");
            System.out.println("[8] Display Enrollment Queue");
            System.out.println("[9] Add Honor Student (Priority Queue)");
            System.out.println("[10] View Honor Students");
            System.out.println("[11] Emergency Message");
            System.out.println("[12] View Emergency Messages");
            System.out.println("[13] Display Statistics");
            System.out.println("[14] Exit");

            try {
                System.out.print("\nEnter Choice (1-14): ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                if (!manager.hasStudents() && choice != 1 && choice != 3 && choice != 4 && choice != 5 && choice != 11 && choice != 12 && choice != 13 && choice != 14) {
                    System.out.println("Please add a student first.");
                    continue;
                }

                switch (choice) {
                    case 1 -> manager.addStudent();
                    case 2 -> manager.displayStudents();
                    case 3 -> manager.addAnnouncement();
                    case 4 -> manager.displayAnnouncements();
                    case 5 -> manager.undoAction();
                    case 6 -> manager.enqueueStudent();
                    case 7 -> manager.serveNextStudent();
                    case 8 -> manager.displayEnrollmentQueue();
                    case 9 -> manager.addHonorStudent();
                    case 10 -> manager.displayHonorStudents();
                    case 11 -> manager.manageEmergencyMessages();
                    case 12 -> manager.displayEmergencyMessages();
                    case 13 -> manager.displayStatistics();
                    case 14 -> {
                        System.out.println("\n" + "=".repeat(60));
                        System.out.println(" Thank you for using the");
                        System.out.println(" University Student Management System");
                        System.out.println("=".repeat(60));

                        scanner.close();
                        return;
                    }

                    default -> System.out.println("Invalid choice. Please enter a number between 1-14.");
                }

            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a whole number.");
                scanner.nextLine();
            }
        }

    }
}