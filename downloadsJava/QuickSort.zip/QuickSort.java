import java.util.*;

class Customer{
    int customerID;
    String name;

    Customer(int customerID, String name){
        this.customerID = customerID;
        this.name = name;
    }

    void display(){
        System.out.println("Customer ID        : " + customerID);
        System.out.println("Customer Name      : " + name);
    }
}
class Car{
    int carID;
    String brand;
    String model;
    double price;
    boolean sold;
    int customerID;

    Car(int carID, String brand, String model, double price){
        this.carID = carID;
        this.brand = brand;
        this.model = model;
        this.price = price;
        sold = false;
        customerID = -1;
    }

    void display(){
        System.out.println("Car ID           : " + carID);
        System.out.println("Car Brand        : " + brand);
        System.out.println("Car Model        : " + model);
        System.out.printf("Price          : $%,.2f%n", price);

        if (sold){
            System.out.println("Status : Sold");
            System.out.println("Owner ID : " + customerID);
        }
        else{
            System.out.println("Status : Available");
        }
    }


}

class Purchase{
    int purchaseID; 
    int customerID;
    int carID;

    Purchase(int purchaseID, int customerID, int carID){
        this.purchaseID = purchaseID;
        this.customerID = customerID;
        this.carID = carID;
    }
}


class CarDealershipManagement{
    private Scanner scanner;
    private Customer[] customers;
    private Car[] cars;
    private Purchase[] purchases;
    private int customerCount;
    private int carCount;
    private int purchaseCount;
    
    public CarDealershipManagement(Scanner scanner){
        this.scanner = scanner;
        customers = new Customer[50];
        cars = new Car[100];
        purchases = new Purchase[100];
        customerCount = 0;
        carCount = 0;
        purchaseCount = 0;
    }

    public boolean hasCustomer(){
        return customerCount > 0;
    }
    public boolean hasCars(){
        return carCount > 0;
    }
    public boolean hasPurchase(){
        return purchaseCount >0;
    }

    
    private int inputID(String label) {

        int id;

        while (true) {

            try {

                System.out.print(label + " (1000 - 1999): ");
                id = scanner.nextInt();
                scanner.nextLine();

                if (id < 1000 || id > 1999) {
                    System.out.println("Invalid. Enter between 1000 and 1999.");
                    continue;
                }

                return id;

            } catch (InputMismatchException e) {

                System.out.println("Invalid. Enter a valid number.");
                scanner.nextLine();

            }
        }
    }


    // ==========================================
    // INPUT PERSONS
    // ==========================================
    public void inputCustomers(){
        if (customerCount == customers.length){
            System.out.println("Customers are full. Cannot add more customers.");
            return;
        }

        System.out.println("\nAdding New Customer...");
        customers[customerCount] = inputCustomer();
        customerCount++;

        System.out.println("\nCustomer added successfully.");
    }

    public Customer inputCustomer(){
        String name;

        System.out.println();
        System.out.println("=".repeat(50));
        System.out.println("       CUSTOMER INFORMATION");
        System.out.println("=".repeat(50));

        // ---------------- Order ID ----------------
        while (true){
        int customerID = inputID("Customer ID");

        boolean duplicate = false;

        for (int i = 0; i < customerCount; i++) {
            if (customers[i].customerID == customerID) {
                duplicate = true;
                break;
            }
        }

        if (duplicate) {
            System.out.println("Customer ID already exists.");
            continue;
        }

        // ---------------- Customer Name ----------------
        while(true){
            System.out.print("Customer Name: ");
            name = scanner.nextLine();

            if (name.trim().isEmpty()){
                System.out.println("Error. Customer Name cannot be empty.");
                continue;
            }
            break;
        }
        return new Customer(customerID, name);
    }}

    // ==========================================
    // DISPLAY CUSTOMER
    // ==========================================
    public void displayCustomers(){
        if (!hasCustomer()){
            System.out.println("\nNo customer records available.");
            return;
        }

        for (int i = 0; i < customerCount; i++){
            System.out.println("\nCustomer #: " + (i+1));
            customers[i].display();
            System.out.println("-".repeat(20));
        }
    }

    // ==========================================
    // SEARCH CUSTOMERS
    // ==========================================
    public void searchCustomers(){
        if (!hasCustomer()){
            System.out.println("\nNo customer records available.");
            return;
        }

        int searchCustomerID = inputID("Customer ID");

        boolean hasFound = false;

        for (Customer customer : customers){
            if (customer != null && customer.customerID == searchCustomerID){
                hasFound = true;
                customer.display();
                System.out.println("\n========== CUSTOMER FOUND ==========");
                    break;
            }
        }

        if (!hasFound){
            System.out.println("\nError. Customer ID has not found.");
                }
    }

    // ==========================================
    // INPUT CARS
    // ==========================================
    public void inputCars(){
        if (carCount == cars.length){
            System.out.println("Cars are full. Cannot add more car.");
            return;
        }

        System.out.println("\nAdding New Car...");
        cars[carCount] = inputCar();
        carCount++;

        System.out.println("\nCar added successfully.");
    }

    public Car inputCar(){
        String brand;
        String model;
        double price;

        System.out.println();
        System.out.println("=".repeat(50));
        System.out.println("       CAR INFORMATION");
        System.out.println("=".repeat(50));

        // ---------------- Order ID ----------------
        while (true) {
            int carID = inputID("Car ID");

            boolean duplicate = false;

            for (Car car : cars) {
                if (car != null && car.carID == carID) {
                    duplicate = true;
                    break;
                }
            }

            if (duplicate) {
                System.out.println("Car ID already exists.");
                continue;
            }
    

        // ---------------- Customer Name ----------------
        while(true){
            System.out.print("Car Brand: ");
            brand = scanner.nextLine();

            System.out.print("Car Model: ");
            model = scanner.nextLine();

            if (brand.trim().isEmpty() || model.trim().isEmpty()){
                System.out.println("Error. Car 'Brand' or 'Model' cannot be empty.");
                continue;
            }
            break;
        }

        // ---------------- Total Price ----------------
        while (true){
            try{
                System.out.print("Car Price: $ ");
                price = scanner.nextDouble();
                scanner.nextLine();

                if (price < 0.00){
                    System.out.println("Invalid. Price must be greater than or equal to 0.");
                    continue;
                }
                break;

            }
            catch (InputMismatchException e) {
                System.out.println("Invalid. Please enter a valid number.");
                scanner.nextLine();
            }
        }

        return new Car(carID, brand, model, price);
    }}

    // ==========================================
    // DISPLAY CARS
    // ==========================================
    public void displayCars(){
        if (!hasCars()){
            System.out.println("\nNo car records available.");
            return;
        }

        for (int i = 0; i < carCount; i++){
            System.out.println("\n Car #: " + (i+1));
            cars[i].display();
            System.out.println("-".repeat(20));
        }
    }

    private Customer findCustomer(int customerID) {

    for (int i = 0; i < customerCount; i++) {

        if (customers[i].customerID == customerID) {
            return customers[i];
        }

    }

    return null;
}

private Car findCar(int carID) {

    for (int i = 0; i < carCount; i++) {

        if (cars[i].carID == carID) {
            return cars[i];
        }

    }

    return null;
}
    // ==========================================
    // SEARCH CARS
    // ==========================================
    public void searchCars(){
        if (!hasCars()){
            System.out.println("\nNo car records available.");
            return;
        }

        int searchCarID = inputID("Car ID");

        boolean hasFound = false;

        for (Car car : cars){
            if (car != null && car.carID == searchCarID){
                hasFound = true;
                car.display();
                System.out.println("\n========== CAR FOUND ==========");      
                    break;
            }
        }

        if (!hasFound){
            System.out.println("Error. Car ID has not found.");
                }

    }

    public void buyCar() {

    if (!hasCustomer()) {
        System.out.println("No customer records available.");
        return;
    }

    if (!hasCars()) {
        System.out.println("No car records available.");
        return;
    }

    int searchCustomerID = inputID("Customer ID");

    Customer selectedCustomer = findCustomer(searchCustomerID);

    if (selectedCustomer == null) {
        System.out.println("Customer not found.");
        return;
    }

    int searchCarID = inputID("Car ID");

    Car selectedCar = findCar(searchCarID);

    if (selectedCar == null) {
        System.out.println("Car not found.");
        return;
    }

    if (selectedCar.sold) {
        System.out.println("This car has already been sold.");
        return;
    }

    selectedCar.sold = true;
    selectedCar.customerID = selectedCustomer.customerID;

    purchases[purchaseCount] = new Purchase(
            purchaseCount + 1,
            selectedCustomer.customerID,
            selectedCar.carID
    );

    purchaseCount++;

    System.out.println("\n========== PURCHASE SUCCESSFUL ==========");
    System.out.println("Customer : " + selectedCustomer.name);
    System.out.println("Car      : " + selectedCar.brand + " " + selectedCar.model);
    System.out.printf("Price    : $%,.2f%n", selectedCar.price);
}

public void viewPurchases() {

    if (!hasPurchase()) {
        System.out.println("\nNo purchase records available.");
        return;
    }

    for (int i = 0; i < purchaseCount; i++) {

        Purchase purchase = purchases[i];

        Customer customer = findCustomer(purchase.customerID);
        Car car = findCar(purchase.carID);

        System.out.println("\nPurchase #" + purchase.purchaseID);

        System.out.println("Customer : " + customer.name);
        System.out.println("Car      : " + car.brand + " " + car.model);
        System.out.printf("Price    : $%,.2f%n", car.price);

        System.out.println("-".repeat(30));
    }
}
    
    public void quickSort(){
        if (!hasCars()) {
        System.out.println("No car records available.");
        return;
    }

        quickSort(cars, 0, carCount - 1);

    System.out.println("\nCars sorted successfully using Quick Sort.");
    }

    private void quickSort(Car[] cars, int low, int high){
        if (low < high){
            int pivotIndex = partition(cars, low, high);
            quickSort(cars, low, pivotIndex - 1);
            quickSort(cars, pivotIndex +1, high);
        }
    }

    private int partition(Car[] cars, int low, int high){
        double pivot = cars[high].price;

        int i = low - 1;

        for (int j = low; j < high; j++){
            if (cars[j].price <= pivot){
                i++;
                swap(cars, i, j);
            }
        }

        swap (cars, i + 1, high);
        return i+1;
    }

    private void swap(Car[] cars, int i, int j){
        Car temp = cars[i];
        cars[i] = cars[j];
        cars[j] = temp;
        }
    }
    


public class QuickSort{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CarDealershipManagement system = new CarDealershipManagement(scanner);

        while(true){
            System.out.println("\n" + "=".repeat(60));
            System.out.println("      CAR DEALERSHIP MANAGEMENT SYSTEM");
            System.out.println("              Quick Sort");
            System.out.println("=".repeat(60));

            System.out.println("\n--------------- MAIN MENU ---------------");
            System.out.println("[1] Add Customer");
            System.out.println("[2] Add Car");
            System.out.println("[3] Display Customers");
            System.out.println("[4] Display Cars");
            System.out.println("[5] Buy Car");
            System.out.println("[6] View Purchases");
            System.out.println("[7] Quick Sort Cars by Price");
            System.out.println("[8] Search Person");
            System.out.println("[9] Search Car");
            System.out.println("[10] Exit");
            System.out.println("-".repeat(41));
            try {
                System.out.print("Enter Choice (1 - 10): ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {

                    case 1 -> {
                        System.out.println("\nLoading Customer Input...");
                        system.inputCustomers();
                    }

                    case 2 -> {
                        System.out.println("\nLoading Car Input...");
                        system.inputCars();
                    }

                    case 3 -> {
                        System.out.println("\nDisplaying Original Customer List...");
                        system.displayCustomers();
                    }

                    case 4 -> {
                        System.out.println("\nDisplaying Original Car List...");
                        system.displayCars();
                    }

                    case 5 -> {
                        System.out.println("\nLoading Purchase...");
                        system.buyCar();
                        
                    }

                    case 6 -> {
                        System.out.println("\nGenerating Purchases...");
                        system.viewPurchases();
                    }

                    case 7 -> {
                        System.out.println("\nPerforming Quick Sort...");
                        system.quickSort();
                        system.displayCars();
                    }

                    case 8 -> {
                        System.out.println("\nProviding Search Input...");
                        system.searchCustomers();
                    }

                    case 9 -> {
                        System.out.println("\nProviding Search Input...");
                        system.searchCars();
                    }

                    case 10 -> {

                        System.out.println("\n" + "=".repeat(60));
                        System.out.println("          THANK YOU FOR USING");
                        System.out.println("    CAR DEALERSHIP MANAGEMENT SYSTEM");
                        System.out.println();
                        System.out.println(" Week 4 - Data Structures & Algorithms");
                        System.out.println(" Quick Sort");
                        System.out.println("=".repeat(60));

                        scanner.close();
                        return;
                    }

                    default ->
                        System.out.println("Invalid choice. Please enter a number from 1 to 10.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid. Please enter a valid number.");
                scanner.nextLine();
            }
        }
    }
}
