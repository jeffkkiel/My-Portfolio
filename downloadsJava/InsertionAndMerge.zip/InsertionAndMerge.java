import java.util.*;
class Order{
    int orderID;
    String customerName;
    double price;
    double totalAmount;
    int itemCount;

    Order(int orderID, String customerName, double price, int itemCount) {
        this.orderID = orderID;
        this.customerName = customerName;
        this.price = price;
        this.itemCount = itemCount;
        totalAmount = price * itemCount;
    }


    void display(){
        System.out.println("Order ID           : " + orderID);
        System.out.println("Customer Name      : " + customerName);
        System.out.printf("Price              : $%,.2f%n", price);
        System.out.println("Item Count         : " + itemCount);
        System.out.printf("Total Amount         : $%,.2f%n", totalAmount);
    }

}

class OnlineStoreManagementSystem{
    private Scanner scanner;
    private Order[] orders;
    private int orderCount;

    public OnlineStoreManagementSystem(Scanner scanner) {
        this.scanner = scanner;
        orders = new Order[100];
        orderCount = 0;
    }

    public boolean hasOrders() {
        return orderCount > 0;
    }

    // ==========================================
    // INPUT ORDERS
    // ==========================================
    public void inputOrders() {
        if (orderCount == orders.length) {
        System.out.println("Storage is full. Cannot add more orders.");
        return;
    }
        System.out.println("\nAdding New Order...");
        orders[orderCount] = inputOrder();
        orderCount++;

        System.out.println("\nOrder added successfully!");
    }

    // ==========================================
    // INPUT ORDER
    // ==========================================

    public Order inputOrder(){
        int orderID;
        String customerName;
        double price;
        int itemCount;

        System.out.println();
        System.out.println("=".repeat(50));
        System.out.println("       ORDER INFORMATION");
        System.out.println("=".repeat(50));

        // ---------------- Order ID ----------------
        while(true){
            try {
                System.out.print("Order ID (1000 - 1999): ");
                orderID = scanner.nextInt();
                scanner.nextLine();

                if (orderID < 1000 || orderID > 1999){
                    System.out.println("Invalid. Please enter a number between 1000 and 1999.");
                    continue;
                }

                boolean duplicate =false;

                for (Order order : orders){
                    if (order != null && order.orderID == orderID){
                        duplicate = true;
                        break;
                    }
                }

                if (duplicate){
                    System.out.println("Error. Order ID already exists.");
                    continue;
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid. Please enter a valid number.");
                scanner.nextLine();
            }
        }

        // ---------------- Customer Name ----------------
        while(true){
            System.out.print("Customer Name: ");
            customerName = scanner.nextLine();

            if (customerName.trim().isEmpty()){
                System.out.println("Error. Customer Name cannot be empty.");
                continue;
            }
            break;
        }

        // ---------------- Total Amount ----------------
        while (true){
            try{
                System.out.print("Price per Item: $ ");
                price = scanner.nextDouble();
                scanner.nextLine();

                if (price < 0.00){
                    System.out.println("Invalid. Price must be greater than or equal to 0.");
                    continue;
                }
                break;

            }
            catch (InputMismatchException e) {
                System.out.println("Invalid. Please enter a valid number.");
                scanner.nextLine();
            }
        }

        // ---------------- Item Count ----------------
        while (true){
            try{
                System.out.print("Item Count: ");
                itemCount = scanner.nextInt();
                scanner.nextLine();

                if (itemCount <= 0){
                    System.out.println("Invalid. Item count must be greater than 0.");
                    continue;
                }
                break;

            }
            catch (InputMismatchException e) {
                System.out.println("Invalid. Please enter a valid number.");
                scanner.nextLine();
            }
        }

        return new Order(orderID, customerName, price, itemCount);
    }

    // ==========================================
    // Display ORDER
    // ==========================================
    public void displayOrder() {
        if (!hasOrders()) {
            System.out.println("\nNo Order records available.");
            return;
        }

        System.out.println("\n" + "=".repeat(55));
        System.out.println("             ORDER LIST");
        System.out.println("=".repeat(55));

        for (int i = 0; i < orderCount; i++) {
            System.out.println("\nOrder #" + (i + 1));
            System.out.println("-".repeat(40));
            orders[i].display();

            if (i != orderCount - 1) {
                System.out.println("-".repeat(55));
            }
        }
        System.out.println("=".repeat(55));
    }

    // ==========================================
    // SEARCH ORDER
    // ==========================================
    public void searchOrder(){
        if (!hasOrders()) {
        System.out.println("\nNo Order records available.");
        return;
    }

        int searchOrderID;

        while(true){
            try {
                System.out.print("Order ID (1000 - 1999): ");
                searchOrderID = scanner.nextInt();
                scanner.nextLine();

                if (searchOrderID < 1000 || searchOrderID > 1999){
                    System.out.println("Invalid. Please enter a number between 1000 and 1999.");
                    continue;
                }

                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid. Please enter a valid number.");
                scanner.nextLine();
            }
        }

        boolean hasFound = false;

        for (Order order : orders){
            if (order != null && order.orderID == searchOrderID){
                hasFound = true;
                System.out.println("\n========== ORDER FOUND ==========");
                order.display();
                break;
            }
        }

        if (!hasFound) {
        System.out.println("\nOrder not found.");
    }
    }

    // ==========================================
    // DISPLAY STATISTICS
    // ==========================================
    public void displayStatistics(){
        if (!hasOrders()) {
        System.out.println("\nNo Order records available.");
        return;
    }
        Order highest = orders[0];
        Order lowest = orders[0];

        int largeOrdersCount = 0;
        double totalSales = 0;

        for (int i = 0; i < orderCount; i++){
            Order order = orders[i];
            if (order.totalAmount > highest.totalAmount){
                highest = order;
            }

            if (order.totalAmount < lowest.totalAmount){
                lowest = order;
            }

            if (order.totalAmount >= 5000){
                largeOrdersCount++;
            }

            totalSales += order.totalAmount;
        }

        double averageSales = totalSales / orderCount;

        System.out.println("\n" + "=".repeat(60));
        System.out.println("                 ONLINE STORE STATISTICS");
        System.out.println("=".repeat(60));

        System.out.println("\nTotal Orders     : " + orderCount);
        System.out.printf("Total Sales     : %,.2f%n", totalSales);
        System.out.printf("Order Sales Average      : %,.2f%n", averageSales);
        System.out.println("Orders over $ 5,000   : " + largeOrdersCount);

        System.out.println("\n" + "-".repeat(60));
        System.out.println("HIGHEST ORDER");
        System.out.println("-".repeat(60));
        highest.display();

        System.out.println("\n" + "-".repeat(60));
        System.out.println("LOWEST ORDER");
        System.out.println("-".repeat(60));
        lowest.display();

        
    }


    // ==========================================
    // INSERTION SORT BY AMOUNT
    // ==========================================
    public void insertionSortByAmount() {

    if (!hasOrders()) {
        System.out.println("\nNo Order records available.");
        return;
    }

    int comparisons = 0;
    int shifts = 0;

    for (int i = 1; i < orderCount; i++) {

        Order temp = orders[i];
        int j = i - 1;

        System.out.println("\n" + "=".repeat(60));
        System.out.println("PASS " + i);
        System.out.println("=".repeat(60));

        System.out.printf("Current Key: Order ID %d | Amount: %.2f%n",
                temp.orderID,
                temp.totalAmount);

        while (j >= 0) {

            comparisons++;

            System.out.printf(
                    "Comparing %.2f (Order %d) > %.2f (Key)%n",
                    orders[j].totalAmount,
                    orders[j].orderID,
                    temp.totalAmount
            );

            if (orders[j].totalAmount > temp.totalAmount) {

                System.out.println("Action: Shift Order " + orders[j].orderID + " to the right.");

                orders[j + 1] = orders[j];
                shifts++;
                j--;

            } else {

                System.out.println("Action: Stop shifting.");
                break;

            }
        }

        orders[j + 1] = temp;

        System.out.println("\nCurrent Order List:");

        for (int k = 0; k < orderCount; k++) {
            System.out.printf(
                    "%d | %-15s | ₱%.2f | %d items%n",
                    orders[k].orderID,
                    orders[k].customerName,
                    orders[k].totalAmount,
                    orders[k].itemCount
            );
        }

    }

    System.out.println("\n" + "=".repeat(60));
    System.out.println("INSERTION SORT COMPLETED (Lowest Amount → Highest Amount)");
    System.out.println("=".repeat(60));

    displayOrder();

    System.out.println("\nInsertion Sort Statistics");
    System.out.println("-".repeat(35));
    System.out.println("Comparisons : " + comparisons);
    System.out.println("Shifts      : " + shifts);
}

    // ==========================================
    // MAINNNN MERGE SORT
    // ==========================================
    public void mergeSortByID(){
        if (!hasOrders()) {
        System.out.println("\nNo Order records available.");
        return;
    }
        mergeSort(0, orderCount - 1);

        System.out.println("\nOrders successfully sorted by Order ID.");
        displayOrder();
    }

    // ==========================================
    // MERGE SORT
    // ==========================================
    public void mergeSort(int left, int right){
        if (left < right){
            int mid = (left + right) / 2;

            mergeSort(left, mid);
            mergeSort(mid + 1, right);
            merge(left, mid, right);
        }
}

    // ==========================================
    // MERGE ONLY
    // ==========================================
    public void merge(int left, int mid, int right){
        int leftSize = mid - left + 1;
        int rightSize = right - mid;

        Order[] leftArray = new Order[leftSize];
        Order[] rightArray = new Order[rightSize];

        for (int i = 0; i<leftSize; i++){
            leftArray[i] = orders[left + i];
        }

        for (int j = 0; j < rightSize; j++){
            rightArray[j] = orders[mid + 1 + j];
        }

        int i = 0;
        int j = 0;
        int k = left;

        while (i < leftSize && j <rightSize){
            if (leftArray[i].orderID <=  rightArray[j].orderID){
                orders[k] = leftArray[i];
                i++;
            }
            else{
                orders[k] = rightArray[j];
                j++;
            }
            k++;
        }

        while (i < leftSize){
            orders[k] = leftArray[i];
            i++;
            k++;
        }

        while (j < rightSize){
            orders[k] = rightArray[j];
            j++;
            k++;
        }

}
    
}

public class InsertionAndMerge {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        OnlineStoreManagementSystem system = new OnlineStoreManagementSystem(scanner);

        while(true){
            System.out.println("\n" + "=".repeat(60));
            System.out.println("      ONLINE STORE MANAGEMENT SYSTEM");
            System.out.println("          Insertion Sort & Merge Sort");
            System.out.println("=".repeat(60));

            System.out.println("\n--------------- MAIN MENU ---------------");
            System.out.println("[1] Add Order");
            System.out.println("[2] Display Orders");
            System.out.println("[3] Search Order");
            System.out.println("[4] Sort by Total Amount (Insertion Sort)");
            System.out.println("[5] Sort by Order ID (Merge Sort)");
            System.out.println("[6] Display Statistics");
            System.out.println("[7] Exit");
            System.out.println("-".repeat(41));

            try {

                System.out.print("Enter Choice (1 - 7): ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                if (!system.hasOrders() && choice != 1 && choice != 7) {
                    System.out.println("\nPlease input order records first.");
                    continue;
                }

                switch (choice) {

                    case 1 -> {
                        System.out.println("\nLoading Order Input...");
                        system.inputOrders();
                    }

                    case 2 -> {
                        System.out.println("\nDisplaying Original Order List...");
                        system.displayOrder();
                    }

                    case 3 -> {
                        System.out.println("\nLoading Search Input...");
                        system.searchOrder();
                    }

                    case 4 -> {
                        System.out.println("\nPerforming Insertion Sort...");
                        system.insertionSortByAmount();
                    }

                    case 5 -> {
                        System.out.println("\nPerforming Merge Sort...");
                        system.mergeSortByID();
                        
                    }

                    case 6 -> {
                        System.out.println("\nGenerating Statistics...");
                        system.displayStatistics();
                    }

                    case 7 -> {

                        System.out.println("\n" + "=".repeat(60));
                        System.out.println("          THANK YOU FOR USING");
                        System.out.println("    ONLINE STORE MANAGEMENT SYSTEM");
                        System.out.println();
                        System.out.println(" Week 4 - Data Structures & Algorithms");
                        System.out.println(" Insertion Sort & Merge Sort");
                        System.out.println("=".repeat(60));

                        scanner.close();
                        return;
                    }

                    default ->
                        System.out.println("Invalid choice. Please enter a number from 1 to 7.");

                }

            }

            catch (InputMismatchException e) {

                System.out.println("Invalid input. Please enter a whole number.");
                scanner.nextLine();

            }

        }

        }

        

    }
