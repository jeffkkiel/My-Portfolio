import java.util.*;

public class LibraryManagementSystem{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("-".repeat(50));
        System.out.println("---- LIBRARY BOOK MANAGEMENT SYSTEM -----");
        System.out.println("-".repeat(50));


        int booksCount;

        while(true){
            try{
            System.out.print("How many books can the library store: ");
            booksCount = scanner.nextInt();
            scanner.nextLine();

            if (booksCount > 0){
                break;
            }
            else{
                System.out.println("\nInvalid. Number must be greater than 0.");
            }
        }
            catch (InputMismatchException e){
                System.out.println("Invalid. Must be a whole number.");
                scanner.nextLine();
            }
        }

        String[] titles = new String[booksCount];
        String[] authors = new String[booksCount];
        String[] borrowedBy = new String[booksCount];

        while (true){
            System.out.println("-".repeat(50));
            System.out.println("----- Choices -----");
            System.out.println("-".repeat(50));
            System.out.println("1 - Add Book/s");
            System.out.println("2 - Display Books");
            System.out.println("3 - Borrow Book");
            System.out.println("4 - Return Book");
            System.out.println("5 - Search Book");
            System.out.println("6 - Library Report");
            System.out.println("7 - Exit");
            try{
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                switch(choice){
                    case 1 -> addBooks(titles, authors, borrowedBy, scanner);
                    case 2 -> displayBooks(titles, authors, borrowedBy);
                    case 3 -> borrowBook(titles, authors, borrowedBy, scanner);
                    case 4 -> returnBook(titles, authors, borrowedBy, scanner);
                    case 5 -> searchBook(titles, authors, borrowedBy, scanner);
                    case 6 -> libraryReport(titles, authors, borrowedBy);
                    case 7 -> {System.out.println("----- Thank you for using our program.");
                    scanner.close();
                    return;}
                    default -> System.out.println("Invalid. Choice must be between 1 - 7.");
                }
            }
            catch (InputMismatchException e){
                System.out.println("Invalid. Please try again.");
                scanner.nextLine();
            }
        }
    }
    public static void addBooks(String[] titles, String[] authors, String[] borrowedBy, Scanner scanner){
    int index = -1;

    for (int i = 0; i < titles.length; i++){
        if (titles[i] == null){
        index = i;
        break;
        }
    }

    if (index == -1){
        System.out.println("\nLibrary is full.");
        return;
    }


    // Title
    while (true){
        System.out.print("\nEnter book title: ");
        String title = scanner.nextLine();

        if (title.isEmpty()){
            System.out.println("Title cannot be empty. Please try again.");
            continue;
        }

        boolean duplicate = false;

        for (int i = 0; i < titles.length; i++){
            if (titles[i] != null && titles[i].equalsIgnoreCase(title)){
                duplicate = true;
                break;
            }
        }

        if (duplicate){
            System.out.println("Book Title already in the library.");
        }
        else{
            titles[index] = title;
            System.out.println("Book Title SUCCESSFULLY added in the library.");
            break;
        }
    }

    // Author
    while (true){
        System.out.print("\nEnter book author: ");
        String author = scanner.nextLine();

        if (author.isEmpty()){
            System.out.println("Author cannot be empty. Please try again.");
            continue;
        }

        authors[index] = author;
        System.out.println("Book Author SUCESSFULLY added.");
        borrowedBy[index] = null;
        break;

    }

    
    }

    public static void displayBooks(String[] titles, String[] authors, String[] borrowedBy){
        boolean hasBooks = false;

        for (String title : titles) {
            if (title != null) {
                hasBooks = true;
                break;
            }
        }

        if (!hasBooks) {
            System.out.println("No books found.");
            return;
        }

        System.out.println("\n");
        System.out.println("-".repeat(50));
        System.out.println("----- Book Records -----");
        System.out.println("-".repeat(50));

        String status;

        for (int i = 0; i < titles.length; i++){
            if (titles[i] == null){
                continue;
            }

            if (borrowedBy[i] == null){
                status = "Available";
            }
            else{
                status = "Borrowed by: " + borrowedBy[i];
            }
            System.out.printf("Title: %s | Author: %s | Status: %s%n", titles[i], authors[i], status);
        }
    }

    public static void borrowBook(String[] titles, String[] authors, String[] borrowedBy, Scanner scanner){
        boolean hasBooks = false;

        for (String title : titles) {
            if (title != null) {
                hasBooks = true;
                break;
            }
        }

        if (!hasBooks) {
            System.out.println("No books found.");
            return;
        }
        

        // Enter User ID
        int userId;

        while(true){
            try {
                System.out.print("Enter user ID (1000 - 9999): ");
                userId = scanner.nextInt();
                scanner.nextLine();

                if (userId >= 1000 && userId <= 9999){
                    break;
                }
                else{
                    System.out.println("User ID must be between 1000 - 9999.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a whole number.");
                scanner.nextLine();
            }
        }

        // Enter Book
        String title;
        while (true){
            System.out.print("\nEnter book title: ");
            title = scanner.nextLine();

            if (title.isEmpty()){
                System.out.println("Title cannot be empty. Please try again.");
                continue;
            }

        // Find Book
            int index = -1;

            for (int i = 0; i < titles.length; i++){

                if (titles[i] != null && titles[i].equalsIgnoreCase(title)){
                index = i;
                break;
                }
            }

            if (index == -1){
                System.out.println("\nBook not found.");
                return;
                }

            if (borrowedBy[index] != null) {
            System.out.println("Book is already borrowed by User ID: " + borrowedBy[index]);
                return;}

            borrowedBy[index] = String.valueOf(userId);

            System.out.println("Book borrowed successfully.");
            break;
    }
    }
    public static void returnBook(String[] titles, String[] authors, String[] borrowedBy, Scanner scanner){
        boolean hasBooks = false;

        for (String title : titles) {
            if (title != null) {
                hasBooks = true;
                break;
            }
        }

        if (!hasBooks) {
            System.out.println("No books found.");
            return;
        }

        // Enter User Id
        int userId;

        while(true){
            try {
                System.out.print("Enter user ID (1000 - 9999): ");
                userId = scanner.nextInt();
                scanner.nextLine();

                if (userId >= 1000 && userId <= 9999){
                    break;
                }
                else{
                    System.out.println("User ID must be between 1000 - 9999.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a whole number.");
                scanner.nextLine();
            }
        }

        // Enter Book
        String title;
        while (true){
            System.out.print("\nEnter book title: ");
            title = scanner.nextLine();

            if (title.isEmpty()){
                System.out.println("Title cannot be empty. Please try again.");
                continue;
            }

        // Find Book
            int index = -1;

            for (int i = 0; i < titles.length; i++){

                if (titles[i] != null && titles[i].equalsIgnoreCase(title)){
                index = i;
                break;
                }
            }

            if (index == -1){
                System.out.println("\nBook not found.");
                return;
                }

            if (borrowedBy[index] == null) {
            System.out.println("Book is already available");
                return;}

            if (borrowedBy[index].equals(String.valueOf(userId))){
            borrowedBy[index] = null;
            System.out.println("Book is already borrowed by another user.");}

            borrowedBy[index] = null;
            System.out.println("Book returned successfully.");
            break;
            }
    }

    public static void searchBook(String[] titles, String[] authors, String[] borrowedBy, Scanner scanner){
        boolean hasBooks = false;

    for (String title : titles) {
        if (title != null) {
            hasBooks = true;
            break;
        }
    }

    if (!hasBooks) {
        System.out.println("No books found.");
        return;
    }

    System.out.print("Enter book title: ");
    String search = scanner.nextLine();

    for (int i = 0; i < titles.length; i++) {

        if (titles[i] != null &&
            titles[i].equalsIgnoreCase(search)) {

            System.out.println();
            System.out.println("Title : " + titles[i]);
            System.out.println("Author: " + authors[i]);

            if (borrowedBy[i] == null) {
                System.out.println("Status: Available");
            } else {
                System.out.println("Status: Borrowed");
                System.out.println("Borrowed By: " + borrowedBy[i]);
            }

            return;
        }
    }

    System.out.println("Book not found.");
    }

    public static void libraryReport(String[] titles, String[] authors, String[] borrowedBy){

        int totalBooks = 0;
        int borrowedBooks = 0;
        int availableBooks = 0;

        boolean hasBooks = false;

        for (String title : titles) {
            if (title != null) {
                hasBooks = true;
                break;
            }
        }        

        if (!hasBooks) {
            System.out.println("No books found.");
            return;
        }

        System.out.println("\n");
        System.out.println("-".repeat(50));
        System.out.println("----- Library Report -----");
        System.out.println("-".repeat(50));

        for (int i = 0; i < titles.length; i++){
            if (titles[i] == null){
                continue;
            }
            totalBooks++;

            if (borrowedBy[i] == null){
                availableBooks++;
            }
            else{
                borrowedBooks++;
            }
        }
            System.out.println("Total Books Stored: " + totalBooks);
            System.out.println("Borrowed Books: " + borrowedBooks);
            System.out.println("Available Books: " + availableBooks);
    }
}