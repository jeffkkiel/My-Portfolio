import java.util.*;
class Book{
    String title;
    String author;
    int pages;
    double price;

    Book(String title, String author, int pages, double price){
        this.title = title;
        this.author = author;
        this.pages = pages;
        this.price = price;
    }

    void display(){
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Pages: " + pages);
        System.out.printf("Price: %.2f%n", price);
    }
}

class BookStack{
    private Scanner scanner;

    private Book[] stack;
    private int top;
    private int capacity;

    public int getSize() {
    return top + 1;
}

    public boolean isEmpty() {
    return top == -1;
}

    public boolean isFull(){
    return top == capacity - 1;
}

    public BookStack(int capacity, Scanner scanner){
        this.capacity = capacity;
        this.scanner = scanner;
        this.stack = new Book[capacity];
        this.top = -1;
    }

    // Input
    public Book inputBook(){
        String title;
        String author;
        int pages;
        double price;
        while (true){
            System.out.print("Enter Title: ");
            title = scanner.nextLine();

            System.out.print("Enter Author: ");
            author = scanner.nextLine();

            if (title.trim().isEmpty() || author.trim().isEmpty()){
                System.out.println("Title or Author must not be empty.");
                continue;
            }
            break;
        }

        while (true){
            try{
                System.out.print("Enter Pages: ");
                pages = scanner.nextInt();
                scanner.nextLine();
                
                if (pages > 0){
                    break;
                }
                System.out.println("Pages must be greater than 0.");
            }
            catch(InputMismatchException e){
                System.out.println("Invalid. Please enter a valid number.");
                scanner.nextLine();
            }
        }

        while (true){
            try{
                System.out.print("Enter Price: ");
                price = scanner.nextDouble();
                scanner.nextLine();
                
                if (price >= 0){
                    break;
                }
                System.out.println("Price must be greater than or equal to 0.");
            }
            catch(InputMismatchException e){
                System.out.println("Invalid. Please enter a valid number.");
                scanner.nextLine();
            }
        }
        return new Book(title, author, pages, price);
    }


    // ----- STACK OPERATIONS -----

    // Push Book
    // Case 1
    public void push(Book book){
        if (isFull()){
            System.out.println("\nStack Overflow.");
            return;
        }
        stack[++top] = book;
        System.out.println("Book pushed successfully.");
    }

    // Pop Book
    // Case 2
    public void pop(){
        if (isEmpty()){
            System.out.println("\nStack Underflow.");
            return;
        }
        System.out.println("Removed Book:");
        stack[top].display();
        stack[top] = null;
        top--;
    }

    // Peek Book
    // Case 3
    public void peek(){
        if (isEmpty()){
            System.out.println("\nStack Underflow.");
            return;
        }
        stack[top].display();
    }

    // Search Book
    // Case 4
    public void searchBook(){
        if (isEmpty()){
            System.out.println("\nStack Underflow.");
            return;
        }

        boolean hasFound = false;

        String searchTitle;

        while (true){
            System.out.print("Enter Title: ");
            searchTitle = scanner.nextLine();

            if (searchTitle.trim().isEmpty()){
                System.out.println("Title or Author must not be empty.");
                continue;
            }
            break;
        }

        for (int i = top; i >= 0; i--){
            if (stack[i].title.equalsIgnoreCase(searchTitle)){
                System.out.println("----- BOOK FOUND -----");
                stack[i].display();
                hasFound = true;
                break;
            }
        }

        if (!hasFound){
            System.out.println("Book has not found.");
        }
    }

    // Update Book
    // Case 5
    public void updateBook(){
        if (isEmpty()){
            System.out.println("\nStack Underflow.");
            return;
        }

        String searchTitle;

        while (true){
            System.out.print("Enter Title to update: ");
            searchTitle = scanner.nextLine();

            if (searchTitle.trim().isEmpty()){
                System.out.println("Title or Author must not be empty.");
                continue;
            }
            break;
        }

        for (int i = top; i >= 0; i--){
            if (stack[i].title.equalsIgnoreCase(searchTitle)){
                System.out.println("----- BOOK FOUND -----");
                System.out.println("Current Book Information");
                stack[i].display();

                System.out.println("\nEnter New Book Information.");
                
                Book newBook = inputBook();

                stack[i].title = newBook.title;
                stack[i].author = newBook.author;
                stack[i].pages = newBook.pages;
                stack[i].price = newBook.price;

                System.out.println("Book successfully updated.");
                return;
            }
        }
            System.out.println("Book has not found.");
    }

    // Display Stack
    // Case 6
    public void displayStack(){
        if (top == -1){
            System.out.println("\nStack Underflow.");
            return;
        }
        int  number = 1;
        for (int i = top; i >= 0; i--){
            System.out.println("----- Book " + number + " -----");
            stack[i].display();
            System.out.println();
            number++;
        }
    }

    public void displayStatistics(){
        if (isEmpty()){
            System.out.println("\nStack Underflow.");
            return;
        }

        Book expensive = stack[0];
        Book cheapest = stack[0];
        int totalBooks = top +1;
        int totalPages = 0;

        for (int i = top; i >=0; i--){
            if (stack[i].price > expensive.price){
                expensive = stack[i];
            }

            if (stack[i].price < cheapest.price){
                cheapest = stack[i];
            }
            totalPages += stack[i].pages;
        }

        double averagePages = (double) totalPages / totalBooks;
        System.out.println("\n");
        System.out.println("-".repeat(50));
        System.out.println("----- BOOK STATISTICS -----");
        System.out.println("-".repeat(50));

        System.out.println("\nTotal Books : " + totalBooks);
        System.out.println("\nTotal Pages: "+ totalPages);
        System.out.printf("\nAverage Pages : %.2f%n", averagePages);

        System.out.println("\nExpensive Book");
        expensive.display();

        System.out.println("\nCheapest Book");
        cheapest.display();

        
}
}
public class BookStackManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int maxSize;

        while (true) {
            try {
                System.out.print("How many Books? ");
                maxSize = scanner.nextInt();
                scanner.nextLine();

                if (maxSize > 0) {
                    break;
                } else {
                    System.out.println("Number of books must be greater than 0.");
                }

            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a whole number.");
                scanner.nextLine(); // Clear invalid input
            }
        }

        BookStack stack = new BookStack(maxSize, scanner);

        while (true){
            System.out.println("\n");
            System.out.println("-".repeat(50));
            System.out.println("----- BOOK STACK MANAGEMENT SYSTEM -----");
            System.out.println("-".repeat(50));
            System.out.println("\n1 - Push Book");
            System.out.println("2 - Pop Book");
            System.out.println("3 - Peek Top Book");
            System.out.println("4 - Search Book");
            System.out.println("5 - Update Top Book");
            System.out.println("6 - Display Stack");
            System.out.println("7 - Display Statistics");
            System.out.println("8 - Exit");
            try {
                System.out.print("\nEnter your choice (1 - 8): ");
                int choice = scanner.nextInt();
                scanner.nextLine();
                if (stack.isEmpty() &&
                    choice != 1 &&
                    choice != 8) {

                    System.out.println("Please add a book first.");
                        continue;
                    }

                    switch (choice) {
                        case 1 -> {
                            if (stack.isFull()) {
        System.out.println("Stack is already full.");
        break;
    }

    int number;

    while (true) {
        try {
            System.out.print("How many books do you want to add? ");
            number = scanner.nextInt();
            scanner.nextLine();

            if (number <= 0) {
                System.out.println("Number must be greater than 0.");
                continue;
            }

            // Check remaining capacity
            int remaining = maxSize - (stack.getSize());

            if (remaining == 0) {
                System.out.println("Stack is already full.");
                break;
            }

            if (number > remaining) {
                System.out.println("You can only add up to " + remaining + " book(s).");
                continue;


            }
            break;
        } catch (InputMismatchException e) {
            System.out.println("Invalid input.");
            scanner.nextLine();
        }
    }

    for (int i = 1; i <= number; i++) {
        System.out.println("\nBook " + i);

        Book book = stack.inputBook();
        stack.push(book);
    }
}

                    case 2 -> stack.pop();
                    case 3 -> stack.peek();
                    case 4 -> stack.searchBook();
                    case 5 -> stack.updateBook();
                    case 6 -> stack.displayStack();
                    case 7 -> stack.displayStatistics();
                    case 8 -> {System.out.println("\n");
                        System.out.println("-".repeat(50));
                        System.out.println("----- Thank you for using our program.");
                        System.out.println("-".repeat(50));
                        scanner.close();
                        return;
                    }

                    default -> System.out.println("Invalid input. Please enter a number between 1 - 8");

                }

            }
            catch (InputMismatchException e) {
                System.out.println("Invalid. Please enter a whole number.");
                scanner.nextLine();
            }
        }

    }
}
