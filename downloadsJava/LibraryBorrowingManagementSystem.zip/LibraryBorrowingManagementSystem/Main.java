import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        PersonManager personManager = new PersonManager(scanner);
        BookManager bookManager = new BookManager(scanner);
        BorrowManager borrowManager = new BorrowManager(scanner, personManager, bookManager);
        SortManager sortManager = new SortManager(bookManager, personManager);

        int choice;

        do {

            System.out.println();
            System.out.println("======================================================");
            System.out.println("        LIBRARY BORROWING MANAGEMENT SYSTEM");
            System.out.println("======================================================");
            System.out.println("[1]  Add User");
            System.out.println("[2]  Add Book");
            System.out.println("[3]  Display Users");
            System.out.println("[4]  Display Books");
            System.out.println("[5]  Search User");
            System.out.println("[6]  Search Book");
            System.out.println("[7]  Update User");
            System.out.println("[8]  Update Book");
            System.out.println("[9]  Delete User");
            System.out.println("[10] Delete Book");
            System.out.println("[11] Borrow Book");
            System.out.println("[12] Return Book");
            System.out.println("[13] Display Borrowed Books");
            System.out.println("[14] Display Available Books");
            System.out.println("[15] Bubble Sort Books (Title A-Z)");
            System.out.println("[16] Selection Sort Users (ID Ascending)");
            System.out.println("[17] Insertion Sort Books (Pages Descending)");
            System.out.println("[18] Exit");
            System.out.println("======================================================");

            while (true) {

                try {

                    System.out.print("Enter your choice: ");
                    choice = scanner.nextInt();
                    scanner.nextLine();

                    if (choice < 1 || choice > 18) {
                        System.out.println("Invalid choice.");
                        continue;
                    }

                    break;

                } catch (Exception e) {

                    System.out.println("Invalid input.");
                    scanner.nextLine();

                }

            }

            switch (choice) {

                case 1:
                    personManager.inputPersons();
                    break;

                case 2:
                    bookManager.inputBooks();
                    break;

                case 3:
                    personManager.displayPersons();
                    break;

                case 4:
                    bookManager.displayBooks();
                    break;

                case 5:
                    personManager.searchPerson();
                    break;

                case 6:
                    bookManager.searchBook();
                    break;

                case 7:
                    personManager.updatePerson();
                    break;

                case 8:
                    bookManager.updateBook();
                    break;

                case 9:
                    personManager.deletePerson();
                    break;

                case 10:
                    bookManager.deleteBook();
                    break;

                case 11:
                    borrowManager.borrowBook();
                    break;

                case 12:
                    borrowManager.returnBook();
                    break;

                case 13:
                    borrowManager.displayBorrowedBooks();
                    break;

                case 14:
                    borrowManager.displayAvailableBooks();
                    break;

                case 15:
                    sortManager.bubbleSortBooks();
                    break;

                case 16:
                    sortManager.selectionSortPersons();
                    break;

                case 17:
                    sortManager.insertionSortBooks();
                    break;

                case 18:
                    System.out.println("\nThank you for using the Library Borrowing Management System!");
                    break;

            }

        } while (choice != 18);

        scanner.close();

    }

}