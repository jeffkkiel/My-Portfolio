class Person{
    int personID;
    String name;

    Person(int personID, String name){
        this.personID = personID;
        this.name = name;
    }

    void display(){
        System.out.println("User ID   : " + personID);
        System.out.println("Name        : " + name);
    }
}