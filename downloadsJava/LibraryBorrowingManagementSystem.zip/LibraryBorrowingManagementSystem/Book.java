class Book {
    int bookID;
    String title;
    String author;
    int pages;
    boolean borrowed;
    int borrowerID;

    Book(int bookID, String title, String author, int pages) {
        this.bookID = bookID;
        this.title = title;
        this.author = author;
        this.pages = pages;
        borrowed = false;
        borrowerID = -1;
    }

    void display(){
        System.out.println("Book ID           : " + bookID);
        System.out.println("Book Title        : " + title);
        System.out.println("Book Author       : " + author);
        System.out.println("Number of Pages   : " +  pages);

        if (borrowed){
            System.out.println("Status : Borrowed");
            System.out.println("Owner ID : " + borrowerID);
        }
        else{
            System.out.println("Status : Available");
        }
    }
    }