

class SortManager{
    private BookManager bookManager;
    private PersonManager personManager;
    public SortManager(BookManager bookManager,
                   PersonManager personManager){

    this.bookManager = bookManager;
    this.personManager = personManager;

}
    public void bubbleSortBooks(){
        Book[] books = bookManager.getBooks();
        int count = bookManager.getBookCount();

        if (count <= 1) {
            System.out.println("Not enough books to sort.");
            return;
    }       

        for (int i = 0; i < count - 1; i++){
            for(int j = 1; j <count - 1 -i; j++){
                if (books[j].title.compareToIgnoreCase(books[j +1].title) > 0){
                    Book temp = books[j];
                    books[j] = books[j+1];
                    books[j+1] = temp;

                }
            }
        }
        System.out.println("\nBooks sorted successfully using Bubble Sort!");
        bookManager.displayBooks();
    }

    public void selectionSortPersons(){
        Person[] persons = personManager.getPersons();
        int count = personManager.getPersonCount();
    

    if (count <= 1) {
        System.out.println("Not enough users to sort.");
        return;
    }

    for (int i = 0; i < count; i++){
        int minIndex = i;
        
        for (int j = i + 1; j < count; j++){
            if (persons[j].personID < persons[minIndex].personID){
                minIndex = j;
            }
        }
        if (minIndex != i){
            Person temp = persons[i];
            persons[i] = persons[minIndex];
            persons[minIndex] = temp;
        }
    }
    System.out.println("\nUsers sorted successfully using Selection Sort!");

    personManager.displayPersons();
}

    public void insertionSortBooks(){
         Book[] books = bookManager.getBooks();
    int count = bookManager.getBookCount();

    if (count <= 1) {
        System.out.println("Not enough books to sort.");
        return;
    }

    for (int i = 1; i < count; i ++){
        Book key= books[i];
        int j = i - 1;

        while (j >= 0 && books[j].pages <key.pages){
            books[j+1] = books[j];
            j--;
        }

    books[j+1] = key;
    }
    System.out.println("\nBooks sorted successfully using Insertion Sort!");
    bookManager.displayBooks();
    }

    
}