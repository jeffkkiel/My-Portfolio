import java.util.*;
class BorrowManager{
    private Scanner scanner;
    private PersonManager personManager;
    private BookManager bookManager;

    public BorrowManager(
        Scanner scanner,
        PersonManager personManager,
        BookManager bookManager){

    this.scanner = scanner;
    this.personManager = personManager;
    this.bookManager = bookManager;}

    //==========================================
    // INPUT USER ID
    //==========================================

    private int inputUserID() {

        int id;

        while (true) {

            try {

                System.out.print("User ID: ");
                id = scanner.nextInt();
                scanner.nextLine();
                return id;

            } catch (InputMismatchException e) {

                System.out.println("Invalid ID.");
                scanner.nextLine();

            }

        }

    }

    //==========================================
    // INPUT BOOK ID
    //==========================================

    private int inputBookID() {

        int id;

        while (true) {

            try {

                System.out.print("Book ID: ");
                id = scanner.nextInt();
                scanner.nextLine();
                return id;

            } catch (InputMismatchException e) {

                System.out.println("Invalid ID.");
                scanner.nextLine();

            }

        }

    }

    // Borrow book
    public void borrowBook(){
        System.out.println("\n========== BORROW BOOK ==========");
        int personID = inputUserID();
        int personIndex = personManager.findPersonIndex(personID);

        if (personIndex == -1){
            System.out.println("User not found.");
            return;
        }

        int bookID = inputBookID();
        int bookIndex = bookManager.findBookIndex(bookID);

        if (bookIndex == -1){
            System.out.println("Book not found.");
            return;
        }

        Book book = bookManager.getBook(bookIndex);

        if (book.borrowed){
            System.out.println("Book already borrowed.");
            return;
        }

        book.borrowed = true;
        book.borrowerID = personID;

        System.out.println("\nBook borrowed successfully!");
        System.out.println("Borrower ID : " + personID);
        System.out.println("Book ID     : " + bookID);
        
    }

    public void returnBook(){
        System.out.println("\n========== RETURN BOOK ==========");

        int bookID= inputBookID();
        int bookIndex = bookManager.findBookIndex(bookID);

        if (bookIndex == -1){
            System.out.println("Book already borrowed.");
            return;
        }

        Book book = bookManager.getBook(bookIndex);

        if (!book.borrowed){
            System.out.println("Book is already available.");
            return;
        }

        book.borrowed = false;
        book.borrowerID = -1;

        System.out.println("\nBook return successfully.");
    }

    public void displayBorrowedBooks(){
        boolean found = false;
        System.out.println("\n========== BORROWED BOOKS ==========");

        for (int i  = 0;i < bookManager.getBookCount();i++){
            Book book = bookManager.getBook(i);
            if(book.borrowed){
                book.display();
                System.out.println("-".repeat(20));
                found = true;
            }
        }

        if (!found){
            System.out.println("No borrowed books.");
        }
    }

    public void displayAvailableBooks(){
        boolean found = false;
        System.out.println("\n========== AVAILABLE BOOKS ==========");

        for (int i =0; i< bookManager.getBookCount();i++){
            Book book = bookManager.getBook(i);
            if (!book.borrowed){
                book.display();
                System.out.println("-".repeat(20));
                found = true;
            }
        }

        if (!found){
            System.out.println("No available books.");
        }
    }
}