import java.util.*;

class BookManager {

    private Scanner scanner;
    private Book[] books;
    private int bookCount;

    public BookManager(Scanner scanner) {
        this.scanner = scanner;
        books = new Book[100];
        bookCount = 0;
    }

    public boolean hasBook() {
        return bookCount > 0;
    }   

    public int getBookCount(){
        return bookCount;
    }
    public Book[] getBooks(){
        return books;
}
    public Book getBook(int index){
        return books[index];}

    private int inputID(String label) {

        int id;

        while (true) {

            try {

                System.out.print(label + " (5000 - 5999): ");
                id = scanner.nextInt();
                scanner.nextLine();

                if (id < 5000 || id > 5999) {
                    System.out.println("Invalid. Enter between 5000 and 5999.");
                    continue;
                }

                return id;

            } catch (InputMismatchException e) {

                System.out.println("Invalid. Enter a valid number.");
                scanner.nextLine();

            }

        }

    }

    private int inputPages() {

        int pages;

        while (true) {

            try {

                System.out.print("Number of Pages: ");
                pages = scanner.nextInt();
                scanner.nextLine();

                if (pages <= 0) {
                    System.out.println("Pages must be greater than 0.");
                    continue;
                }

                return pages;

            } catch (InputMismatchException e) {

                System.out.println("Invalid number.");
                scanner.nextLine();

            }

        }

    }

    public int findBookIndex(int id) {

        for (int i = 0; i < bookCount; i++) {

            if (books[i].bookID == id) {
                return i;
            }

        }

        return -1;

    }

    // ==========================================
    // INPUT BOOK
    // ==========================================

    public void inputBooks() {

        if (bookCount == books.length) {

            System.out.println("Library is full.");
            return;

        }

        System.out.println("\nAdding New Book...");

        books[bookCount] = inputBook();

        bookCount++;

        System.out.println("\nBook added successfully.");

    }

    public Book inputBook() {

        String title;
        String author;

        System.out.println();
        System.out.println("=".repeat(50));
        System.out.println("        BOOK INFORMATION");
        System.out.println("=".repeat(50));

        while (true) {

            int bookID = inputID("Book ID");

            boolean duplicate = false;

            for (int i = 0; i < bookCount; i++) {

                if (books[i].bookID == bookID) {

                    duplicate = true;
                    break;

                }

            }

            if (duplicate) {

                System.out.println("Book ID already exists.");
                continue;

            }

            while (true) {

                System.out.print("Book Title: ");
                title = scanner.nextLine();

                if (title.trim().isEmpty()) {

                    System.out.println("Title cannot be empty.");
                    continue;

                }

                break;

            }

            while (true) {

                System.out.print("Author: ");
                author = scanner.nextLine();

                if (author.trim().isEmpty()) {

                    System.out.println("Author cannot be empty.");
                    continue;

                }

                break;

            }

            int pages = inputPages();

            return new Book(bookID, title, author, pages);

        }

    }

    // ==========================================
    // DISPLAY BOOKS
    // ==========================================

    public void displayBooks() {

        if (!hasBook()) {

            System.out.println("\nNo books available.");
            return;

        }

        for (int i = 0; i < bookCount; i++) {

            System.out.println("\nBook #: " + (i + 1));
            books[i].display();
            System.out.println("-".repeat(20));

        }

    }

    // ==========================================
    // SEARCH BOOK
    // ==========================================

    public void searchBook() {

        if (!hasBook()) {

            System.out.println("\nNo books available.");
            return;

        }

        int searchBookID = inputID("Book ID");

        int index = findBookIndex(searchBookID);

        if (index == -1) {

            System.out.println("\nBook not found.");
            return;

        }

        System.out.println("\n========== BOOK FOUND ==========");
        books[index].display();

    }

    // ==========================================
    // UPDATE BOOK
    // ==========================================

    public void updateBook() {

        if (!hasBook()) {

            System.out.println("\nNo books available.");
            return;

        }

        int searchBookID = inputID("Book ID");

        int index = findBookIndex(searchBookID);

        if (index == -1) {

            System.out.println("\nBook not found.");
            return;

        }

        System.out.println("\n========== BOOK FOUND ==========");
        books[index].display();

        int newBookID;

        while (true) {

            newBookID = inputID("New Book ID");

            boolean duplicate = false;

            for (int i = 0; i < bookCount; i++) {

                if (i != index && books[i].bookID == newBookID) {

                    duplicate = true;
                    break;

                }

            }

            if (duplicate) {

                System.out.println("Book ID already exists.");
                continue;

            }

            break;

        }

        String newTitle;

        while (true) {

            System.out.print("New Title: ");
            newTitle = scanner.nextLine();

            if (newTitle.trim().isEmpty()) {

                System.out.println("Title cannot be empty.");
                continue;

            }

            break;

        }

        String newAuthor;

        while (true) {

            System.out.print("New Author: ");
            newAuthor = scanner.nextLine();

            if (newAuthor.trim().isEmpty()) {

                System.out.println("Author cannot be empty.");
                continue;

            }

            break;

        }

        int newPages = inputPages();

        books[index].bookID = newBookID;
        books[index].title = newTitle;
        books[index].author = newAuthor;
        books[index].pages = newPages;

        System.out.println("\nBook updated successfully!");

    }

    // ==========================================
    // DELETE BOOK
    // ==========================================

    public void deleteBook() {

        if (!hasBook()) {

            System.out.println("\nNo books available.");
            return;

        }

        int deleteBookID = inputID("Book ID");

        int index = findBookIndex(deleteBookID);

        if (index == -1) {

            System.out.println("\nBook not found.");
            return;

        }

        if (books[index].borrowed) {

            System.out.println("\nCannot delete.");
            System.out.println("Book is currently borrowed.");
            return;

        }

        System.out.println("\n========== BOOK FOUND ==========");
        books[index].display();

        for (int i = index; i < bookCount - 1; i++) {

            books[i] = books[i + 1];

        }

        books[bookCount - 1] = null;

        bookCount--;

        System.out.println("\nBook deleted successfully!");

    }

}