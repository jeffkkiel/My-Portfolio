import java.util.*;

class PersonManager{
    private Scanner scanner;
    private Person[] persons;
    private int personCount;

    public PersonManager(Scanner scanner) {
        this.scanner = scanner;
        this.persons = new Person[100];
        personCount = 0;
    }

    public boolean hasPerson(){
        return personCount > 0;
    }

    public Person[] getPersons(){
    return persons;
}   

    public int getPersonCount(){
        return personCount;
    }
    public Person getPerson(int index){
         return persons[index];}

    private int inputID(String label) {

        int id;
        while (true) {
            try {
                System.out.print(label + " (1000 - 1999): ");
                id = scanner.nextInt();
                scanner.nextLine();

                if (id < 1000 || id > 1999) {
                    System.out.println("Invalid. Enter between 1000 and 1999.");
                    continue;
                }
                return id;

            } catch (InputMismatchException e) {
                System.out.println("Invalid. Enter a valid number.");
                scanner.nextLine();
            }
        }
    }

    public int findPersonIndex(int id){
        for (int i = 0; i < personCount; i++) {

            if(persons[i].personID == id){
                return i;
            }
        }
        return -1;
    }

    // ==========================================
    // INPUT PERSONS
    // ==========================================
    public void inputPersons(){
        if (personCount == persons.length){
            System.out.println("Users are full. Cannot add more user.");
            return;
        }

        System.out.println("\nAdding New User...");
        persons[personCount] = inputPerson();
        personCount++;

        System.out.println("\nUser added successfully.");
    }

    public Person inputPerson(){
        String name;

        System.out.println();
        System.out.println("=".repeat(50));
        System.out.println("       USER INFORMATION");
        System.out.println("=".repeat(50));

        // ---------------- uSER ID ----------------
        while (true) {

            int personID = inputID("User ID");

            boolean duplicate = false;

            for (int i = 0; i < personCount; i++) {
                if (persons[i].personID == personID) {
                    duplicate = true;
                    break;
                }
            }

            if (duplicate) {
                System.out.println("User ID already exists.");
                continue;
            }

        // ---------------- Customer Name ----------------
            while (true) { 
                
            System.out.print("User Name: ");
            name = scanner.nextLine();

            if (name.trim().isEmpty()){
                System.out.println("Error. User Name cannot be empty.");
                continue;
            }
            break;
        }
        return new Person(personID, name);
    }}

    // ==========================================
    // DISLPLAY PERSONS
    // ==========================================

    public void displayPersons(){
        if (!hasPerson()){
            System.out.println("\nNo user records available.");
            return;
        }

        for (int i =0; i <personCount; i++){
            System.out.println("\nUser #: " + (i+1));
            persons[i].display();
            System.out.println("-".repeat(20));
        }
    }

    // ==========================================
    // SEARCH PERSONS
    // ==========================================
    public void searchPerson(){
        if (!hasPerson()){
            System.out.println("\nNo user records available.");
            return;
        }

        int searchPersonID = inputID("User ID");

        int index = findPersonIndex(searchPersonID);

        if (index == -1) {
            System.out.println("\nUser not found.");
            return;
        }

        System.out.println("\n========== USER FOUND ==========");
        persons[index].display();

    }

    // ==========================================
    // UPDATE PERSONS
    // ==========================================
    public void updatePerson(){
        if (!hasPerson()){
            System.out.println("\nNo user records available.");
            return;
        }
         int searchPersonID = inputID("User ID");

    int index = findPersonIndex(searchPersonID);

    if (index == -1) {
        System.out.println("\nUser not found.");
        return;
    }

    System.out.println("\n========== USER FOUND ==========");
    persons[index].display();

    // Ask for new ID
    int newPersonID;

    while (true) {
        newPersonID = inputID("New User ID");

        boolean duplicate = false;

        for (int i = 0; i < personCount; i++) {
            if (i != index && persons[i].personID == newPersonID) {
                duplicate = true;
                break;
            }
        }

        if (duplicate) {
            System.out.println("User ID already exists.");
            continue;
        }

        break;
    }

    // Ask for new name
    String newName;

    while (true) {
        System.out.print("New User Name: ");
        newName = scanner.nextLine();

        if (newName.trim().isEmpty()) {
            System.out.println("Error. User Name cannot be empty.");
            continue;
        }

        break;
    }

    // Update object
    persons[index].personID = newPersonID;
    persons[index].name = newName;

    System.out.println("\nUser updated successfully!");
        
    }

     // ==========================================
    // DELETE PERSON
    // ==========================================   
    public void deletePerson(){
        if (!hasPerson()){
            System.out.println("\nNo user records available.");
            return;
        }

        int deletePersonID = inputID("User ID");
        int index = findPersonIndex(deletePersonID);

        if (index == -1){
            System.out.println("\nUser not found.");
            return;
        }

        System.out.println("\n========== USER FOUND ==========");
        persons[index].display();

        for (int i = index; i<personCount - 1;i++){
            persons[i] = persons[i+1];
        }

        persons[personCount - 1] =null;
        personCount --;

        System.out.println("\nUser deleted successfully!");
    }
}

