package DSA.Queues;

import java.util.*;

class Patient {
    int patientID;
    String name;
    int age;
    String illness;

    Patient(int patientID, String name, int age, String illness) {
        this.patientID = patientID;
        this.name = name;
        this.age = age;
        this.illness = illness;
    }

    void display() {
        System.out.println("Patient ID   : " + patientID);
        System.out.println("Name         : " + name);
        System.out.println("Age          : " + age);
        System.out.println("Illness      : " + illness);
    }

}

class PatientQueue {
    private Patient[] queue;
    private int front;
    private int rear;
    private int capacity;
    private Scanner scanner;

    public PatientQueue(int capacity, Scanner scanner) {
        this.capacity = capacity;
        this.scanner = scanner;
        this.queue = new Patient[capacity];
        this.front = -1;
        this.rear = -1;
    }

    public boolean isEmpty() {
        return front == -1;
    }

    public boolean isFull() {
        return rear == capacity - 1;
    }

    public int getSize() {
        if (isEmpty())
            return 0;
        return rear - front + 1;
    }

    // ================= INPUT =================
    public Patient inputPatient() {
        int patientID;
        String name;
        int age;
        String illness;

        System.out.println("=".repeat(50));
        System.out.println("           ENTER PATIENT INFORMATION");
        System.out.println("=".repeat(50));

        while (true) {
            try {
                System.out.print("Patient ID (1000-1999): ");
                patientID = scanner.nextInt();
                scanner.nextLine();

                if (patientID >= 1000 && patientID <= 1999)
                    break;

                System.out.println("Invalid ID. Must be between 1000-1999.");
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Enter a valid number.");
                scanner.nextLine();
            }
        }

        while (true) {
            System.out.print("Patient Name           : ");
            name = scanner.nextLine();

            if (!name.trim().isEmpty())
                break;

            System.out.println("Name cannot be empty.");
        }

        while (true) {
            try {
                System.out.print("Age                    : ");
                age = scanner.nextInt();
                scanner.nextLine();

                if (age > 0)
                    break;

                System.out.println("Age must be greater than 0.");
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Enter a valid number.");
                scanner.nextLine();
            }
        }

        while (true) {
            System.out.print("Illness                : ");
            illness = scanner.nextLine();

            if (!illness.trim().isEmpty())
                break;

            System.out.println("Illness cannot be empty.");
        }

        return new Patient(patientID, name, age, illness);
    }

    // ================= ENQUEUE =================
    public void enqueue(Patient patient) {
        if (isFull()) {
            System.out.println("Queue Overflow!");
            return;
        }

        if (isEmpty()) {
            front = 0;
        }

        rear++;
        queue[rear] = patient;

        System.out.println("\nPatient Added Successfully!");
        System.out.println("Current Queue Size: " + getSize() + "/" + capacity);
    }

    // ================= DEQUEUE =================
    public void dequeue() {
        if (isEmpty()) {
            System.out.println("Queue Underflow!");
            return;
        }

        System.out.println("\n" + "=".repeat(50));
        System.out.println("               PATIENT SERVED");
        System.out.println("=".repeat(50));

        queue[front].display();

        queue[front] = null;

        if (front == rear) {
            front = -1;
            rear = -1;
        } else {
            front++;
        }

        System.out.println("\nPatient removed from queue successfully.");
    }

    // ================= PEEK =================
    public void peek() {
        if (isEmpty()) {
            System.out.println("Queue Underflow!");
            return;
        }

        System.out.println("\n" + "=".repeat(50));
        System.out.println("             FRONT PATIENT");
        System.out.println("=".repeat(50));

        queue[front].display();
    }

    // ================= SEARCH =================
    public void searchPatient() {
        if (isEmpty()) {
            System.out.println("Queue Underflow!");
            return;
        }

        int searchID;

        while (true) {
            try {
                System.out.print("Enter Patient ID to search: ");
                searchID = scanner.nextInt();
                scanner.nextLine();
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input.");
                scanner.nextLine();
            }
        }

        for (int i = front; i <= rear; i++) {
            if (queue[i].patientID == searchID) {
                System.out.println("\nPatient Found!");
                queue[i].display();
                System.out.println("Position in Queue: " + (i - front + 1));
                return;
            }
        }

        System.out.println("Patient not found.");
    }

    // ================= UPDATE =================
    public void updatePatient() {
        if (isEmpty()) {
            System.out.println("Queue Underflow!");
            return;
        }

        int searchID;

        while (true) {
            try {
                System.out.print("Enter Patient ID to update: ");
                searchID = scanner.nextInt();
                scanner.nextLine();
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input.");
                scanner.nextLine();
            }
        }

        for (int i = front; i <= rear; i++) {
            if (queue[i].patientID == searchID) {
                System.out.println("\nCurrent Patient Information");
                queue[i].display();

                System.out.println("\nEnter New Patient Information");
                Patient updated = inputPatient();

                queue[i] = updated;

                System.out.println("\nPatient updated successfully.");
                return;
            }
        }

        System.out.println("Patient not found.");
    }

    // ================= DISPLAY QUEUE =================
    public void displayQueue() {
        if (isEmpty()) {
            System.out.println("Queue Underflow!");
            return;
        }

        System.out.println("\n" + "=".repeat(50));
        System.out.println("               CURRENT QUEUE");
        System.out.println("=".repeat(50));

        System.out.println("\nFRONT\n");

        for (int i = front; i <= rear; i++) {
            System.out.println("Patient #" + (i - front + 1));
            System.out.println("-".repeat(30));
            queue[i].display();
            System.out.println();
        }

        System.out.println("REAR");
    }

    // ================= STATISTICS =================
    public void displayStatistics() {
        if (isEmpty()) {
            System.out.println("Queue Underflow!");
            return;
        }

        Patient oldest = queue[front];
        Patient youngest = queue[front];

        int totalPatients = 0;
        int totalAge = 0;

        for (int i = front; i <= rear; i++) {
            if (queue[i].age > oldest.age)
                oldest = queue[i];
            if (queue[i].age < youngest.age)
                youngest = queue[i];

            totalPatients++;
            totalAge += queue[i].age;
        }

        double averageAge = (double) totalAge / totalPatients;

        System.out.println("\n" + "=".repeat(50));
        System.out.println("             HOSPITAL STATISTICS");
        System.out.println("=".repeat(50));

        System.out.println("Total Patients : " + totalPatients);
        System.out.printf("Average Age    : %.2f%n", averageAge);

        System.out.println("\nOldest Patient");
        System.out.println("-".repeat(30));
        oldest.display();

        System.out.println("\nYoungest Patient");
        System.out.println("-".repeat(30));
        youngest.display();
    }

}

// ================= MAIN PROGRAM =================
public class HospitalQueueManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int maxSize;

        System.out.println("=".repeat(60));
        System.out.println("         HOSPITAL QUEUE MANAGEMENT SYSTEM");
        System.out.println("=".repeat(60));

        while (true) {
            try {
                System.out.print("Enter Maximum Queue Capacity: ");
                maxSize = scanner.nextInt();
                scanner.nextLine();

                if (maxSize > 0)
                    break;

                System.out.println("Capacity must be greater than 0.");

            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Enter a whole number.");
                scanner.nextLine();
            }
        }

        PatientQueue queue = new PatientQueue(maxSize, scanner);

        while (true) {
            System.out.println("\n" + "=".repeat(60));
            System.out.println("         HOSPITAL QUEUE MANAGEMENT SYSTEM");
            System.out.println("=".repeat(60));

            System.out.println("Current Queue: " + queue.getSize() + "/" + maxSize);

            System.out.println("\n[1] Enqueue Patient");
            System.out.println("[2] Dequeue Patient");
            System.out.println("[3] Peek Front Patient");
            System.out.println("[4] Search Patient");
            System.out.println("[5] Update Patient");
            System.out.println("[6] Display Queue");
            System.out.println("[7] Display Statistics");
            System.out.println("[8] Exit");

            try {
                System.out.print("\nEnter Choice (1-8): ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                if (queue.isEmpty() && choice != 1 && choice != 8) {
                    System.out.println("Please add a patient first.");
                    continue;
                }

                switch (choice) {
                    case 1 -> {
                        if (queue.isFull()) {
                            System.out.println("Queue is already full.");
                            break;
                        }

                        int number;

                        while (true) {
                            try {
                                System.out.print("How many patients do you want to add? ");
                                number = scanner.nextInt();
                                scanner.nextLine();

                                int remaining = maxSize - queue.getSize();

                                if (number <= 0) {
                                    System.out.println("Number must be greater than 0.");
                                    continue;
                                }

                                if (number > remaining) {
                                    System.out.println("You can only add up to " + remaining + " patient(s).");
                                    continue;
                                }

                                break;

                            } catch (InputMismatchException e) {
                                System.out.println("Invalid input.");
                                scanner.nextLine();
                            }
                        }

                        for (int i = 1; i <= number; i++) {
                            System.out.println("\nPatient #" + i);
                            Patient patient = queue.inputPatient();
                            queue.enqueue(patient);
                        }
                    }

                    case 2 -> queue.dequeue();
                    case 3 -> queue.peek();
                    case 4 -> queue.searchPatient();
                    case 5 -> queue.updatePatient();
                    case 6 -> queue.displayQueue();
                    case 7 -> queue.displayStatistics();

                    case 8 -> {
                        System.out.println("\n" + "=".repeat(60));
                        System.out.println(" Thank you for using the");
                        System.out.println(" Hospital Queue Management System");
                        System.out.println("=".repeat(60));

                        scanner.close();
                        return;
                    }

                    default -> System.out.println("Invalid choice. Please enter a number between 1-8.");
                }

            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a whole number.");
                scanner.nextLine();
            }
        }
    }
}
